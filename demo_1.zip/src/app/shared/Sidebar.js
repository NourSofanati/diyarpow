import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';
import { Dropdown } from 'react-bootstrap';
import { Redirect } from "react-router-dom";
import getLang from './Translations'
class Sidebar extends Component {
  stateSat = false;
  constructor(props) {
    super(props)
    this.state = {
      firstName: '',
      lastName: '',
      role: '',
      language: ''
    };
  }
  componentDidMount() {
    const rememberMe = localStorage.getItem('userData');
    if (!rememberMe && window.location.href !== "https://diyarpower.com/demo/user-pages/login-1") {
      return <Redirect to={'/users-pages/login-1'} />
    }
    this.onRouteChanged();
    const body = document.querySelector('body');
    document.querySelectorAll('.sidebar .nav-item').forEach((el) => {

      el.addEventListener('mouseover', function () {
        if (body.classList.contains('sidebar-icon-only')) {
          el.classList.add('hover-open');
        }
      });
      el.addEventListener('mouseout', function () {
        if (body.classList.contains('sidebar-icon-only')) {
          el.classList.remove('hover-open');
        }
      });
    });
  }
  toggleMenuState(menuState) {
    if (this.state[menuState]) {
      this.setState({ [menuState]: false });
    } else if (Object.keys(this.state).length === 0) {
      this.setState({ [menuState]: true });
    } else {
      Object.keys(this.state).forEach(i => {
        this.setState({ [i]: false });
      });
      this.setState({ [menuState]: true });
    }

  }

  componentDidUpdate(prevProps) {
    if (this.props.location !== prevProps.location) {
      this.onRouteChanged();
    }

  }

  onRouteChanged() {
    document.querySelector('#sidebar').classList.remove('active');
    Object.keys(this.state).forEach(i => {
      this.setState({ [i]: false });
    });

    const dropdownPaths = [
      { path: '/basic-ui', state: 'basicUiMenuOpen' },
      { path: '/form-elements', state: 'formElementsMenuOpen' },
      { path: '/tables', state: 'tablesMenuOpen' },
      { path: '/icons', state: 'iconsMenuOpen' },
      { path: '/charts', state: 'chartsMenuOpen' },
      { path: '/user-pages', state: 'userPagesMenuOpen' },
    ];

    dropdownPaths.forEach((obj => {
      if (this.isPathActive(obj.path)) {
        this.setState({ [obj.state]: true })
      }
    }));

  }
  render() {
    if (localStorage.getItem('userData'))

      return (
        <nav className="sidebar sidebar-offcanvas" id="sidebar">
          <div className="text-center sidebar-brand-wrapper d-flex align-items-center">
            <a className="sidebar-brand brand-logo" href="index.html"><img height="250px" src={require("../../assets/images/Capture.PNG")} alt="logo" /></a>
          </div>
          <ul className="nav pt-3">
            <li className="nav-item nav-profile not-navigation-link">
              <div className="nav-link">
                <Dropdown>
                  <Dropdown.Toggle className="nav-link user-switch-dropdown-toggler p-0 toggle-arrow-hide bg-transparent border-0 w-100">
                    <div className="d-flex justify-content-between align-items-start">
                      <div className="profile-image">
                        <img src="https://www.ibts.org/wp-content/uploads/2017/08/iStock-476085198.jpg" alt="profile" />
                      </div>
                      <div className="text-left ml-3">
                        <p className="profile-name">{JSON.parse(localStorage.getItem('userData')).firstName} {JSON.parse(localStorage.getItem('userData')).lastName}</p>
                        <small className="designation text-muted text-small">{JSON.parse(localStorage.getItem('userData')).role}</small>
                        <span className="status-indicator online"></span>
                      </div>
                    </div>
                  </Dropdown.Toggle>
                </Dropdown>
                <Link className="btn btn-success btn-block" to="/add-data">{getLang(localStorage.getItem('language') || 'English', "Add Data")}<i className="mdi mdi-plus"></i></Link>
              </div>
            </li>
            <li className={this.isPathActive('/dashboard') ? 'nav-item active' : 'nav-item'}>
              <Link className="nav-link" to="/dashboard">
                <i className="mdi mdi-television menu-icon"></i>
                <span className="menu-title">{getLang(localStorage.getItem('language') || 'English', "Dashboard")}</span>
              </Link>
            </li>
            <li className={this.isPathActive('/archive') ? 'nav-item active' : 'nav-item'}>
              <Link className="nav-link" to="/archive">
                <i className="mdi mdi-television menu-icon"></i>
                <span className="menu-title">{getLang(localStorage.getItem('language') || 'English', "Archive")}</span>
              </Link>
            </li>
            {(localStorage.getItem('userData') && (JSON.parse(localStorage.getItem('userData')).role === 'Production' || JSON.parse(localStorage.getItem('userData')).role === 'Administrator')) ? < li className={this.isPathActive('/add-data') ? 'nav-item active' : 'nav-item'}>
              <Link className="nav-link" to="/add-data">
                <i className="mdi mdi-plus menu-icon"></i>
                <span className="menu-title">{getLang(localStorage.getItem('language') || 'English', "Add Production Data")}</span>
              </Link>
            </li> : null
            }
            {(localStorage.getItem('userData') && (JSON.parse(localStorage.getItem('userData')).role === 'Lab' || JSON.parse(localStorage.getItem('userData')).role === 'Administrator')) ? <li className={this.isPathActive('/add-water') ? 'nav-item active' : 'nav-item'}>
              <Link className="nav-link" to="/add-water">
                <i className="mdi mdi-plus menu-icon"></i>
                <span className="menu-title">{getLang(localStorage.getItem('language') || 'English', "Add Watercut data")}</span>
              </Link>
            </li> : null}
            {(localStorage.getItem('userData') && (JSON.parse(localStorage.getItem('userData')).role === 'Lab' || JSON.parse(localStorage.getItem('userData')).role === 'Administrator')) ? <li className={this.isPathActive('/water-analysis-report') ? 'nav-item active' : 'nav-item'}>
              <Link className="nav-link" to="/water-analysis-report">
                <i className="mdi mdi-water menu-icon"></i>
                <span className="menu-title">{getLang(localStorage.getItem('language') || 'English', "Add water analysis report")}</span>
              </Link>
            </li> : null}
            {(localStorage.getItem('userData') && (JSON.parse(localStorage.getItem('userData')).role === 'Lab' || JSON.parse(localStorage.getItem('userData')).role === 'Administrator')) ? <li className={this.isPathActive('/oil-analysis-report') ? 'nav-item active' : 'nav-item'}>
              <Link className="nav-link" to="/oil-analysis-report">
                <i className="mdi mdi-fuel menu-icon"></i>
                <span className="menu-title">{getLang(localStorage.getItem('language') || 'English', "Add oil analysis report")}</span>
              </Link>
            </li> : null}
            {(localStorage.getItem('userData') && (JSON.parse(localStorage.getItem('userData')).role === 'Production' || JSON.parse(localStorage.getItem('userData')).role === 'Administrator')) ? <li className={this.isPathActive('/wells') ? 'nav-item active' : 'nav-item'}>
              <Link className="nav-link" to="/wells">
                <i className="mdi mdi-water-well menu-icon"></i>
                <span className="menu-title">{getLang(localStorage.getItem('language') || 'English', "Wells")}</span>
              </Link>
            </li> : null}
            {(localStorage.getItem('userData') && (JSON.parse(localStorage.getItem('userData')).role === 'Production' || JSON.parse(localStorage.getItem('userData')).role === 'Administrator')) ? <li className={this.isPathActive('/multiphase') ? 'nav-item active' : 'nav-item'}>
              <Link className="nav-link" to="/multiphase">
                <i className="mdi mdi-water-well menu-icon"></i>
                <span className="menu-title">{getLang(localStorage.getItem('language') || 'English', "Multiphase")}</span>
              </Link>
            </li> : null}
            {(localStorage.getItem('userData') && (JSON.parse(localStorage.getItem('userData')).role === 'Production' || JSON.parse(localStorage.getItem('userData')).role === 'Administrator')) ? <li className={this.isPathActive('/timer') ? 'nav-item active' : 'nav-item'}>
              <Link className="nav-link" to="/timer">
                <i className="mdi mdi-timer menu-icon"></i>
                <span className="menu-title">{getLang(localStorage.getItem('language') || 'English', "Testing")}</span>
              </Link>
            </li> : null}
            {(localStorage.getItem('userData') && (JSON.parse(localStorage.getItem('userData')).role === 'Production' || JSON.parse(localStorage.getItem('userData')).role === 'Administrator')) ? <li className={this.isPathActive('/remote-connection') ? 'nav-item active' : 'nav-item'}>
              <Link className="nav-link" to="/remote-connection">
                <i className="mdi mdi-remote menu-icon"></i>
                <span className="menu-title">{getLang(localStorage.getItem('language') || 'English', "Remote Connection")}</span>
              </Link>
            </li> : null}
            {(localStorage.getItem('userData') && (JSON.parse(localStorage.getItem('userData')).role === 'Lab' || JSON.parse(localStorage.getItem('userData')).role === 'Administrator')) ? <li className={this.isPathActive('/water-cut-report') ? 'nav-item active' : 'nav-item'}>
              <Link className="nav-link" to="/water-cut-report">
                <i className="mdi mdi-water menu-icon"></i>
                <span className="menu-title">{getLang(localStorage.getItem('language') || 'English', "Water cut reports")}</span>
              </Link>
            </li> : null}
            {(localStorage.getItem('userData') && (JSON.parse(localStorage.getItem('userData')).role === 'Production' || JSON.parse(localStorage.getItem('userData')).role === 'Administrator')) ? <li className='nav-item'>
              <Link className="nav-link" to="/generateReport">
                <i className="mdi mdi-book menu-icon"></i>
                <span className="menu-title">{getLang(localStorage.getItem('language') || 'English', "Generate Report")}</span>
              </Link>
            </li> : null}
            {(localStorage.getItem('userData') && (JSON.parse(localStorage.getItem('userData')).role === 'Lab' || JSON.parse(localStorage.getItem('userData')).role === 'Administrator')) ? <li className={this.isPathActive('/water-cut-report') ? 'nav-item active' : 'nav-item'}>
              <a className="nav-link" href="https://diyarpower.com/writeReport.html">
                <i className="mdi mdi-book menu-icon"></i>
                <span className="menu-title">{getLang(localStorage.getItem('language') || 'English', "Write Analyisis Report")}</span>
              </a>
            </li> : null}
          </ul>
        </nav >
      );
    else
      return (
        <nav className="navbar col-lg-12 col-12 p-lg-0 fixed-top d-flex flex-row" ></nav>
      );
  }

  isPathActive(path) {
    return this.props.location.pathname.startsWith(path);
  }
}

export default withRouter(Sidebar);