import React, { Component } from 'react';

class Footer extends Component {
  render () {
    return (
      <footer className="footer">
        <div className="container-fluid">
          <div className="d-sm-flex justify-content-center justify-content-sm-between">
              
              <p className="text-muted">Designed and developed by <a href="https://nayzac.online">Nayzac™</a></p>
            
          </div>
        </div>
      </footer>
    );
  }
}

export default Footer;