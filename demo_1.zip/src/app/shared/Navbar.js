import React, { Component } from 'react';
import { Dropdown } from 'react-bootstrap';
import { Link, withRouter } from 'react-router-dom';
import getLang from './Translations'
class Navbar extends Component {
  stateSat = false;
  toggleOffcanvas() {
    document.querySelector('.sidebar-offcanvas').classList.toggle('active');
  }
  state = {
    firstName: '',
    lastName: '',
    times: '',
    language: '',
  };

  componentDidMount() {
    const rememberMe = localStorage.getItem('userData');
    console.log(rememberMe)
    if (!rememberMe && window.location.href.indexOf("user-pages/login-1") < 0) {
      window.location.href = "/user-pages/login-1"
    }
    setInterval(() => {
      this.setState({
        times: new Date().toLocaleTimeString(),
      });
    }, 100);

    window.onkeydown = e => {
      if (e.key === 'p') this.playAudio();
    }
  }
  playAudio() {
    document.querySelector('#audio').pause();
    document.querySelector('#audio').currentTime = 0;
    document.querySelector('#audio').play();
  }

  renderExpirements() {
    if (localStorage.getItem('userData') && (JSON.parse(localStorage.getItem('userData')).role === 'Lab' || JSON.parse(localStorage.getItem('userData')).role === 'Administrator')) {
      return <li className={this.isPathActive('/add-data') ? "nav-item active d-none d-xl-flex" : "nav-item d-none d-xl-flex"}>
        <Link className="nav-link" to="/add-data">
          <i className="mdi mdi-flask"></i>{getLang(localStorage.getItem('language') || 'English', "Labratory")}</Link>
      </li>;
    }
  }
  renderProduction() {
    if (localStorage.getItem('userData') && (JSON.parse(localStorage.getItem('userData')).role === 'Production' || JSON.parse(localStorage.getItem('userData')).role === 'Administrator')) {
      return <li className={this.isPathActive('/reports') ? "nav-item active d-none d-xl-flex" : "nav-item d-none d-xl-flex"}>
        <Link to="/reports" className="nav-link">
          <i className="mdi mdi-elevation-rise"></i>{getLang(localStorage.getItem('language') || 'English', "Production")}</Link>
      </li>;
    }
  }
  isPathActive(path) {
    return this.props.location.pathname.startsWith(path);
  }
  render() {
    if (localStorage.getItem('userData'))
      return (
        <nav className="navbar col-lg-12 col-12 p-lg-0 fixed-top d-flex flex-row">
          <div className="navbar-menu-wrapper d-flex align-items-center justify-content-between">

            <button className="navbar-toggler navbar-toggler align-self-center" type="button" onClick={() => document.body.classList.toggle('sidebar-icon-only')}>
              <i className="mdi mdi-menu"></i>
            </button>
            <ul className="navbar-nav navbar-nav-left header-links">
              {
                this.renderProduction()
              }
              {
                this.renderExpirements()
              }
            </ul>
            <audio src="https://diyarpower.com/pristine.mp3" autoPlay id="audio"></audio>
            <ul className="navbar-nav navbar-nav-right ml-lg-auto">
              <li className="nav-item border-0">
                {
                  this.state.times
                }
              </li>
              <li className="nav-item  nav-profile border-0 pl-4">
                <Dropdown alignRight>
                  <Dropdown.Toggle className="nav-link count-indicator p-0 toggle-arrow-hide bg-transparent mr-5">
                    <i className="mdi mdi-web"></i>
                    <Dropdown.Menu className="navbar-dropdown preview-list">
                      <Dropdown.Item className="dropdown-item py-3 d-flex" onClick={() => {
                        localStorage.setItem("language", "English");
                        window.location.assign(window.location.href);
                      }}>
                        <div className="d-flex justify-content-between align-items-middle w-100">
                          <h5 className="pr-3">{getLang(localStorage.getItem('language') || 'English', "English")}</h5> <img src={require("../../assets/images/united-states.svg")} width="25" height="25" alt="US Flag"></img>
                        </div>
                      </Dropdown.Item>
                      <Dropdown.Item className="dropdown-item py-3 d-flex" onClick={() => {
                        localStorage.setItem("language", "Arabic");
                        window.location.assign(window.location.href);
                      }}>
                        <div className="d-flex justify-content-between align-items-middle w-100">
                          <h5 className="pr-3">{getLang(localStorage.getItem('language') || 'English', "Arabic")}</h5> <img src={require("../../assets/images/syria.svg")} width="25" height="25" alt="SY Flag"></img>
                        </div>
                      </Dropdown.Item>
                      <Dropdown.Item className="dropdown-item py-3 d-flex" onClick={() => {
                        localStorage.setItem("language", "Spanish");
                        window.location.assign(window.location.href);
                      }}>
                        <div className="d-flex justify-content-between align-items-middle w-100">
                          <h5 className="pr-3">{getLang(localStorage.getItem('language') || 'English', "Spanish")}</h5> <img src={require("../../assets/images/spain.svg")} width="25" height="25" alt="ES Flag"></img>
                        </div>
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown.Toggle>
                </Dropdown>
                <div className="bg-transparent pointer" >
                  <div className="nav-link count-indicator p-0 toggle-arrow-hide bg-transparent" onClick={() => {
                    window.open('http://diyarpower.com:80/converter/index.html', 'popup', "width=395,height=540")

                  }}>
                    <i className="mdi mdi-calculator-variant"></i>
                  </div>
                </div>
              </li>
              <li className="nav-item  nav-profile border-0 pl-4">
                <Dropdown alignRight>
                  <Dropdown.Toggle className="nav-link count-indicator p-0 toggle-arrow-hide bg-transparent">
                    <i className="mdi mdi-bell-outline"></i>
                  </Dropdown.Toggle>
                  <Dropdown.Menu className="navbar-dropdown preview-list">
                    <Dropdown.Item className="dropdown-item preview-item d-flex align-items-center border-0 mt-2" >
                      No notifications...
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </li>
              <li className="nav-item  nav-profile border-0">
                <Dropdown alignRight>
                  <Dropdown.Toggle className="nav-link count-indicator bg-transparent">
                    <span className="profile-text" id="username">{this.state.firstName} {this.state.lastName}</span>
                  </Dropdown.Toggle>
                  <Dropdown.Menu className="preview-list navbar-dropdown pb-3">
                    <Dropdown.Item className="dropdown-item preview-item d-flex align-items-center border-0 mt-2" onClick={evt => evt.preventDefault()}>
                      {getLang(localStorage.getItem('language') || 'English', "Manage Accounts")}
                    </Dropdown.Item>
                    <Dropdown.Item className="dropdown-item preview-item d-flex align-items-center border-0" onClick={evt => evt.preventDefault()}>
                      {getLang(localStorage.getItem('language') || 'English', "Change Password")}
                    </Dropdown.Item>
                    <Dropdown.Item className="dropdown-item preview-item d-flex align-items-center border-0" onClick={evt => { localStorage.removeItem('userData'); window.location.href = "/user-pages/login-1" }}>
                      {getLang(localStorage.getItem('language') || 'English', "Sign Out")}
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </li>
            </ul>
            <button className="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" onClick={this.toggleOffcanvas}>
              <span className="mdi mdi-menu"></span>
            </button>
          </div>
        </nav >
      );
    else
      return (
        <nav className="navbar col-lg-12 col-12 p-lg-0 fixed-top d-flex flex-row"></nav>
      );
  }
}

export default withRouter(Navbar);

