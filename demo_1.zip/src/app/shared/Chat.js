import React, { Component } from 'react';

export class Chat extends Component {
    url; username; chatWindow;
    constructor(props) {
        super(props);
        this.state = {
            collapsed: true,
        }
    }
    componentDidMount() {
        this.url = "https://diyarpower.com/converter/index.html";
        // this.username = JSON.parse(localStorage.getItem('userData')).username;

    }
    collapse() {
        this.setState({ collapsed: !this.state.collapsed })
    }

    render() {
        return (
            <div className="floating card border shadow">
                <div className="card-header" onClick={() => this.collapse()}>
                    Units Plus
                    
                </div>
                <iframe id="chatWindow" title="Units Plus" src={this.url} frameBorder="0" height="540px" className={this.state.collapsed ? 'hideChat' : ''}></iframe>
            </div>
        );
    }
}

export default Chat;