import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Form } from 'react-bootstrap';
import { Redirect } from "react-router-dom";

export class Login extends Component {

  render() {
    if (localStorage.getItem('userData') != null) {
      //window.location.href = "https://diyarpower.com/demo/dashboard";
      return <Redirect to={'/dashboard'} />
    } else
      return (
        <div>
          <div className="d-flex align-items-center auth px-0">
            <div className="row w-100 mx-0">
              <div className="col-lg-4 mx-auto">
                <div className="auth-form-light text-left py-5 px-4 px-sm-5">
                  {/* <div className="brand-logo">
                  <img src={require("../../assets/images/logo.svg")} alt="logo" />
                </div> */}
                  <h4>Login</h4>
                  {/* <h6 className="font-weight-light">Sign in to continue.</h6> */}
                  <Form className="pt-3"  >
                    <Form.Group className="d-flex search-field">
                      <Form.Control type="text" placeholder="Username" size="lg" className="h-auto" id="username" />
                    </Form.Group>
                    <Form.Group className="d-flex search-field">
                      <Form.Control type="password" placeholder="Password" size="lg" className="h-auto" id="password" />
                    </Form.Group>
                    <div className="mt-3">
                      {/* <Link className="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" onClick={e => submitData()}>SIGN IN</Link> */}
                      <Form.Control type="submit" onClick={(e) => { e.preventDefault(); submitData()}} value="LOGIN"></Form.Control>
                    </div>
                    {/* <div className="mb-2">
                    <button type="button" className="btn btn-block btn-facebook auth-form-btn">
                      <i className="mdi mdi-facebook mr-2"></i>Connect using facebook
                    </button>
                  </div> */}
                    <div className="text-center mt-4 font-weight-light">
                      Don't have an account? <Link to="/user-pages/register" className="text-primary">Create</Link>
                    </div>
                  </Form>
                </div>
              </div>
            </div>
          </div>
        </div>
      )
  }
}

export default Login

window.onload = e => {
  console.log(e);

}

function submitData() {
  var raw = JSON.stringify({
    "username": document.querySelector('#username').value,
    "password": document.querySelector('#password').value
  });
  console.log(raw);
  var requestOptions = {
    method: 'POST',
    body: raw,
  };

  fetch("https://diyarpower.com/scripts/Users/auth.php", requestOptions)
    .then(response => response.json())
    .then(result => {
      if (result.success === true) {
        console.log('Logged in');
        localStorage.setItem('userData', JSON.stringify(result));
        window.location.href = '/dashboard'
      }
    })
    .catch(error => console.log('error', error));
}