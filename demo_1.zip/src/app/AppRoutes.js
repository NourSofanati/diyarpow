import React, { Component, Suspense, lazy } from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';

import Spinner from '../app/shared/Spinner';
import Bill from './dashboard/Bill';
import CoiledTubing from './dashboard/CoiledTubing';
import Nitrogen from './dashboard/Nitrogen';
import Workhover from './dashboard/Workhover';

const Dashboard = lazy(() => import('./dashboard/Dashboard'));
const Reports = lazy(() => import('./dashboard/Reports'));
const AddDataPage = lazy(() => import('./dashboard/AddDataPage'));
const OilAnalysisPage = lazy(() => import('./dashboard/OilAnalysisReport'));
const WaterCutReport = lazy(() => import('./dashboard/WaterCutReport'));
const PumpInformationPage = lazy(() => import('./dashboard/PumpInformationPage'));
const Wells = lazy(() => import('./dashboard/Wells'));
const Multiphase = lazy(() => import('./dashboard/Multiphase'));
const Timer = lazy(() => import('./dashboard/Timer'));
const AddWaterCut = lazy(() => import('./dashboard/AddWaterPage'));
const RemoteConnectionPage = lazy(() => import('./dashboard/RemoteDesktop'));
const WaterAnalysisPage = lazy(() => import('./dashboard/WaterAnalysisReport'));
const GenerateReportPage = lazy(() => import('./dashboard/GenerateReport'));
const Archive = lazy(() => import('./dashboard/Archive'));


const Error404 = lazy(() => import('./user-pages/Error404'));
const Error500 = lazy(() => import('./user-pages/Error500'));

const Login = lazy(() => import('./user-pages/Login'));
const Register1 = lazy(() => import('./user-pages/Register'));

const BlankPage = lazy(() => import('./user-pages/BlankPage'));


class AppRoutes extends Component {
  render() {
    return (
      <Suspense fallback={<Spinner />}>
        <Switch>
          <Route exact path="/dashboard" component={Dashboard} />
          <Route exact path="/reports" component={Reports} />
          <Route exact path="/add-data" component={AddDataPage} />
          <Route exact path="/add-water" component={AddWaterCut} />
          <Route exact path="/pumps-info" component={PumpInformationPage} />
          <Route exact path="/remote-connection" component={RemoteConnectionPage} />
          <Route exact path="/water-analysis-report" component={WaterAnalysisPage} />
          <Route exact path="/water-cut-report" component={WaterCutReport} />
          <Route exact path="/oil-analysis-report" component={OilAnalysisPage} />
          <Route exact path="/wells" component={Wells} />
          <Route exact path="/multiphase" component={Multiphase} />
          <Route exact path="/timer" component={Timer} />
          <Route exact path="/generateReport" component={GenerateReportPage} />
          <Route exact path="/archive" component={Archive} />
          <Route exact path="/nitrogen" component={Nitrogen} />
          <Route exact path="/workhover" component={Workhover} />
          <Route exact path="/coiled-tubing" component={CoiledTubing} />
          <Route exact path="/bill" component={Bill} />

          <Route path="/user-pages/login-1" component={Login} />
          <Route path="/user-pages/register-1" component={Register1} />

          <Route path="/user-pages/error-404" component={Error404} />
          <Route path="/user-pages/error-500" component={Error500} />

          <Route path="/user-pages/blank-page" component={BlankPage} />


          <Redirect to="/dashboard" />
        </Switch>
      </Suspense>
    );
  }
}

export default AppRoutes;