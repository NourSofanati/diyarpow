import React, { Component } from 'react'
import { Form } from 'react-bootstrap';
import getLang from './Translations'
export class Bill extends Component {
    state = {
        data: [],
        wells: [],
        year: new Date().getFullYear(),
        month: new Date().getMonth(),
        selectedWells: []
    };
    componentWillMount() {
        fetch("https://diyarpower.com/scripts/Wells/read.php")
            .then(response => response.json())
            .then(result => {

                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ wells: x });

                console.log(this.state);
            })
            .catch(error => console.log('error', error));
        if (JSON.parse(localStorage.getItem('userData')).username !== 'Office') {
            window.location.href = "/dashboard";
        }
    }
    render() {
        return (
            <div>
                <div className="page-header">
                    <h3 className="page-title"> Generate Report </h3>
                </div>
                <div className="col-md-12 grid-margin stretch-card">
                    <div className="card">
                        <div className="card-header">
                            <h3>Invoice (Secret option)</h3>
                        </div>
                        <div className="card-body">


                            <br>
                            </br>
                            <form className="forms-sample" action="https://diyarpower.com/scripts/Wells/invoice.php">
                                <Form.Group>
                                    <label htmlFor="wells">{getLang(localStorage.getItem('language') || 'English', 'Well NO')}</label>
                                    <Form.Control as="select" multiple placeholder="Field Name" id="wells" name="wells[]" size="lg" htmlSize="10" >
                                        {
                                            this.state.wells.map(el => <option val={el.wellNO} size="lg" >{el.wellNO}</option>)
                                        }
                                    </Form.Control>
                                </Form.Group>
                                <Form.Group>
                                    <div className="d-flex w-50 justify-content-between">

                                        <label htmlFor="year">{getLang(localStorage.getItem('language') || 'English', 'Year')}</label>
                                        <input required type="number" className="form-control" id="year" name="year" placeholder="Year" value={this.state.year}
                                            onChange={(val) => { this.setState({ year: val.val }) }} />

                                        <label htmlFor="month">{getLang(localStorage.getItem('language') || 'English', 'month')}</label>
                                        <input required type="number" className="form-control" id="month" name="month" placeholder="month" value={this.state.month} onChange={(val) => { this.setState({ month: val.val }) }} />
                                    </div>
                                </Form.Group>
                                <input type="submit" value="Submit" />
                            </form>
                        </div>
                    </div>
                </div>
            </div >
        )
    }
}

export default Bill
