import React, { Component } from 'react'

let staticData = `[
  {
    "WELL NO": "WDO 1",
    "KB": 505,
    "Formation": "",
    "Formation Top": 1103,
    "drainage intervals m": "1200 -1175",
    "Thickness of drainage inttervals. M": 25,
    "Production method": "beam pump",
    "GOR m3/m3": 15,
    "API gravity": 20,
    "pump diametre inch": 2.5,
    "Depth pump running .m": 1100,
    "length stroke.m": 3,
    "Reservoir pumping speed (per min)": 6,
    "dynamic level m": 500,
    "theoretical Production": 82,
    "Pump efficiency": 0.61,
    "oil": 14,
    "Water": 36,
    "Fluid": 50,
    "Flooding %": 73,
    "pump factor": 4.56,
    "AWPA": "yes",
    "AWPA  run date": "3/5/2020"
  },
  {
    "WELL NO": "WDO 2",
    "KB": 487,
    "Formation": "",
    "Formation Top": 1185,
    "drainage intervals m": "1296 -1261SEL",
    "Thickness of drainage inttervals. M": 19,
    "Production method": "beam pump",
    "GOR m3/m3": 20,
    "API gravity": 15,
    "pump diametre inch": 2.5,
    "Depth pump running .m": 1260,
    "length stroke.m": 4,
    "Reservoir pumping speed (per min)": 6,
    "dynamic level m": 180,
    "theoretical Production": 109,
    "Pump efficiency": 0.87,
    "oil": 11,
    "Water": 84,
    "Fluid": 95,
    "Flooding %": 88,
    "pump factor": 4.56,
    "AWPA": "No",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDO 3",
    "KB": 498,
    "Formation": "",
    "Formation Top": 1183,
    "drainage intervals m": "1254 -1232",
    "Thickness of drainage inttervals. M": 22,
    "Production method": "ESP",
    "GOR m3/m3": 18,
    "API gravity": 17,
    "pump diametre inch": "",
    "Depth pump running .m": "",
    "length stroke.m": "",
    "Reservoir pumping speed (per min)": "",
    "dynamic level m": "",
    "theoretical Production": "",
    "Pump efficiency": "",
    "oil": "",
    "Water": "",
    "Fluid": "",
    "Flooding %": "",
    "pump factor": "",
    "AWPA": "No",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDO 4",
    "KB": 490,
    "Formation": "",
    "Formation Top": 1158,
    "drainage intervals m": "1295 -1265",
    "Thickness of drainage inttervals. M": 30,
    "Production method": "PCP",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": "",
    "Depth pump running .m": "",
    "length stroke.m": "",
    "Reservoir pumping speed (per min)": "",
    "dynamic level m": "",
    "theoretical Production": "",
    "Pump efficiency": "",
    "oil": "",
    "Water": "",
    "Fluid": "",
    "Flooding %": "",
    "pump factor": "",
    "AWPA": "No",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDO 5",
    "KB": 504,
    "Formation": "",
    "Formation Top": 1157,
    "drainage intervals m": "1216 -1157 sl",
    "Thickness of drainage inttervals. M": 32,
    "Production method": "Gas lift",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": "",
    "Depth pump running .m": "",
    "length stroke.m": "",
    "Reservoir pumping speed (per min)": "",
    "dynamic level m": "",
    "theoretical Production": "",
    "Pump efficiency": "",
    "oil": "",
    "Water": "",
    "Fluid": "",
    "Flooding %": "",
    "pump factor": "",
    "AWPA": "No",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDO 6",
    "KB": 478,
    "Formation": "",
    "Formation Top": 1157,
    "drainage intervals m": "1268-1245",
    "Thickness of drainage inttervals. M": 23,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2,
    "Depth pump running .m": 1220,
    "length stroke.m": 3,
    "Reservoir pumping speed (per min)": 7.5,
    "dynamic level m": 210,
    "theoretical Production": 66,
    "Pump efficiency": 0.91,
    "oil": 8,
    "Water": 52,
    "Fluid": 60,
    "Flooding %": 87,
    "pump factor": 2.92,
    "AWPA": "yes",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDO 7",
    "KB": 494,
    "Formation": "",
    "Formation Top": 1139,
    "drainage intervals m": "1211 -1186",
    "Thickness of drainage inttervals. M": 25,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2.5,
    "Depth pump running .m": 1275,
    "length stroke.m": 4.27,
    "Reservoir pumping speed (per min)": 4,
    "dynamic level m": 240,
    "theoretical Production": 78,
    "Pump efficiency": 0.96,
    "oil": 9,
    "Water": 66,
    "Fluid": 75,
    "Flooding %": 88,
    "pump factor": 4.56,
    "AWPA": "No",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDO 8",
    "KB": 479,
    "Formation": "",
    "Formation Top": 1119,
    "drainage intervals m": "1341-1181 sl",
    "Thickness of drainage inttervals. M": 65,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2.5,
    "Depth pump running .m": 1150,
    "length stroke.m": 4.27,
    "Reservoir pumping speed (per min)": 4,
    "dynamic level m": 100,
    "theoretical Production": 78,
    "Pump efficiency": 0.96,
    "oil": 11,
    "Water": 64,
    "Fluid": 75,
    "Flooding %": 85,
    "pump factor": 4.56,
    "AWPA": "yes",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDO 9",
    "KB": 477,
    "Formation": "",
    "Formation Top": 1148,
    "drainage intervals m": "1198 -1173",
    "Thickness of drainage inttervals. M": 25,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2.5,
    "Depth pump running .m": 1100,
    "length stroke.m": 3.66,
    "Reservoir pumping speed (per min)": 6,
    "dynamic level m": "nm",
    "theoretical Production": 100,
    "Pump efficiency": 0.95,
    "oil": 21,
    "Water": 74,
    "Fluid": 95,
    "Flooding %": 78,
    "pump factor": 4.56,
    "AWPA": "yes",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDO 10",
    "KB": 459,
    "Formation": "",
    "Formation Top": 1136,
    "drainage intervals m": "1185 -1135",
    "Thickness of drainage inttervals. M": 50,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2.5,
    "Depth pump running .m": 1200,
    "length stroke.m": 3,
    "Reservoir pumping speed (per min)": 6,
    "dynamic level m": 160,
    "theoretical Production": 82,
    "Pump efficiency": 0.91,
    "oil": 13,
    "Water": 62,
    "Fluid": 75,
    "Flooding %": 83,
    "pump factor": 4.56,
    "AWPA": "yes",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDO 11",
    "KB": 500,
    "Formation": "",
    "Formation Top": 1162,
    "drainage intervals m": "1210 -1162",
    "Thickness of drainage inttervals. M": 48,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2.5,
    "Depth pump running .m": 1375,
    "length stroke.m": 3,
    "Reservoir pumping speed (per min)": 3.5,
    "dynamic level m": 150,
    "theoretical Production": 48,
    "Pump efficiency": 1.04,
    "oil": 6,
    "Water": 44,
    "Fluid": 50,
    "Flooding %": 88,
    "pump factor": 4.56,
    "AWPA": "yes",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDO 12",
    "KB": 493,
    "Formation": "",
    "Formation Top": 1152,
    "drainage intervals m": "1242-1217",
    "Thickness of drainage inttervals. M": 25,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2.5,
    "Depth pump running .m": 1100,
    "length stroke.m": 4.27,
    "Reservoir pumping speed (per min)": 4,
    "dynamic level m": "nm",
    "theoretical Production": 78,
    "Pump efficiency": 1.09,
    "oil": 19,
    "Water": 66,
    "Fluid": 85,
    "Flooding %": 78,
    "pump factor": 4.56,
    "AWPA": "yes",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDO 13",
    "KB": 466,
    "Formation": "",
    "Formation Top": 1154,
    "drainage intervals m": "1254-1198 OH",
    "Thickness of drainage inttervals. M": 56,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2.5,
    "Depth pump running .m": 1200,
    "length stroke.m": 4.27,
    "Reservoir pumping speed (per min)": 6,
    "dynamic level m": 45,
    "theoretical Production": 117,
    "Pump efficiency": 0.94,
    "oil": 6,
    "Water": 104,
    "Fluid": 110,
    "Flooding %": 95,
    "pump factor": 4.56,
    "AWPA": "yes",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDO 14",
    "KB": 463,
    "Formation": "",
    "Formation Top": 1167,
    "drainage intervals m": "1287-1184 OH",
    "Thickness of drainage inttervals. M": 103,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2.5,
    "Depth pump running .m": 800,
    "length stroke.m": 4.88,
    "Reservoir pumping speed (per min)": 4,
    "dynamic level m": 110,
    "theoretical Production": 89,
    "Pump efficiency": 1.12,
    "oil": 10,
    "Water": 90,
    "Fluid": 100,
    "Flooding %": 90,
    "pump factor": 4.56,
    "AWPA": "yes",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDOH 26",
    "KB": 463,
    "Formation": "",
    "Formation Top": 1167,
    "drainage intervals m": "1287-1184 OH",
    "Thickness of drainage inttervals. M": 104,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2.5,
    "Depth pump running .m": 800,
    "length stroke.m": 4.88,
    "Reservoir pumping speed (per min)": 4,
    "dynamic level m": 110,
    "theoretical Production": 89,
    "Pump efficiency": 1.12,
    "oil": 10,
    "Water": 90,
    "Fluid": 100,
    "Flooding %": 90,
    "pump factor": 4.56,
    "AWPA": "yes",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDOH 27",
    "KB": 463,
    "Formation": "",
    "Formation Top": 1167,
    "drainage intervals m": "1287-1184 OH",
    "Thickness of drainage inttervals. M": 105,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2.5,
    "Depth pump running .m": 800,
    "length stroke.m": 4.88,
    "Reservoir pumping speed (per min)": 4,
    "dynamic level m": 110,
    "theoretical Production": 89,
    "Pump efficiency": 1.12,
    "oil": 10,
    "Water": 90,
    "Fluid": 100,
    "Flooding %": 90,
    "pump factor": 4.56,
    "AWPA": "yes",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDOH 28",
    "KB": 463,
    "Formation": "",
    "Formation Top": 1167,
    "drainage intervals m": "1287-1184 OH",
    "Thickness of drainage inttervals. M": 106,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2.5,
    "Depth pump running .m": 800,
    "length stroke.m": 4.88,
    "Reservoir pumping speed (per min)": 4,
    "dynamic level m": 110,
    "theoretical Production": 89,
    "Pump efficiency": 1.12,
    "oil": 10,
    "Water": 90,
    "Fluid": 100,
    "Flooding %": 90,
    "pump factor": 4.56,
    "AWPA": "yes",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDOH 29",
    "KB": 463,
    "Formation": "",
    "Formation Top": 1167,
    "drainage intervals m": "1287-1184 OH",
    "Thickness of drainage inttervals. M": 107,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2.5,
    "Depth pump running .m": 800,
    "length stroke.m": 4.88,
    "Reservoir pumping speed (per min)": 4,
    "dynamic level m": 110,
    "theoretical Production": 89,
    "Pump efficiency": 1.12,
    "oil": 10,
    "Water": 90,
    "Fluid": 100,
    "Flooding %": 90,
    "pump factor": 4.56,
    "AWPA": "yes",
    "AWPA  run date": ""
  },
  {
    "WELL NO": "WDOH 30",
    "KB": 463,
    "Formation": "",
    "Formation Top": 1167,
    "drainage intervals m": "1287-1184 OH",
    "Thickness of drainage inttervals. M": 108,
    "Production method": "beam pump",
    "GOR m3/m3": "",
    "API gravity": "",
    "pump diametre inch": 2.5,
    "Depth pump running .m": 800,
    "length stroke.m": 4.88,
    "Reservoir pumping speed (per min)": 4,
    "dynamic level m": 110,
    "theoretical Production": 89,
    "Pump efficiency": 1.12,
    "oil": 10,
    "Water": 90,
    "Fluid": 100,
    "Flooding %": 90,
    "pump factor": 4.56,
    "AWPA": "yes",
    "AWPA  run date": ""
  }
]`;
let data = JSON.parse(staticData);
export class PumpInformationPage extends Component {
  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title">Pumps information</h3>

        </div>
        <div className="col-lg-12 grid-margin stretch-card">
          <div className="card">
            <div className="card-body">
              <h4 className="card-title">Pump info for <code>وادي عبيد</code> </h4>
              <p>Oil well</p>
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>WELL NO</th>
                      <th>KB</th>
                      <th>Formation Top</th>
                      <th>Drianage intervals m</th>
                      <th>Thickness of drainage intervals. M</th>
                    </tr>
                  </thead>
                  <tbody>
                  {
                    data.map((value) => {
                      console.log(value);
                      return <tr>
                        <td>{value["WELL NO"]}</td>
                        <td>{value.KB}</td>
                        <td>{value["Formation Top"]}</td>
                        <td>{value["drainage intervals m"]}</td>
                        <td>{value["Thickness of drainage inttervals. M"]}</td>
                        {/* <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>   */}
                      </tr>
                    })
                  }
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

    )
  }
}

export default PumpInformationPage
