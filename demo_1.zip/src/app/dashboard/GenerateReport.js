import React, { Component } from 'react'
import { Form } from 'react-bootstrap';
import getLang from './Translations'
export class Reports extends Component {
    state = {
        data: [],
        wells: [],
        year: new Date().getFullYear(),
        month: new Date().getMonth(),
        selectedWells: []
    };
    componentWillMount() {
        fetch("https://diyarpower.com/scripts/Wells/read.php")
            .then(response => response.json())
            .then(result => {

                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ wells: x });

                console.log(this.state);
            })
            .catch(error => console.log('error', error));
    }
    render() {
        return (
            <div>
                <div className="page-header">
                    <h3 className="page-title"> Generate Report </h3>
                </div>
                <div className="col-md-12 grid-margin stretch-card">
                    <div className="card">
                        <div className="card-header">
                            <h3>View report data for well</h3>
                        </div>
                        <div className="card-body">


                            <br>
                            </br>
                            <form className="forms-sample" action="https://diyarpower.com/scripts/Wells/table.php">
                                <Form.Group>
                                    <label htmlFor="wells">{getLang(localStorage.getItem('language') || 'English', 'Well NO')}</label>
                                    <Form.Control as="select" multiple placeholder="Field Name" id="wells" name="wells[]" size="lg" htmlSize="10" >
                                        {
                                            this.state.wells.map(el => <option val={el.wellNO} size="lg" >{el.wellNO}</option>)
                                        }
                                    </Form.Control>
                                </Form.Group>
                                <Form.Group>
                                    <label htmlFor="from">{getLang(localStorage.getItem('language') || 'English', 'From')}</label>
                                    <input required type="date" className="form-control" name="from" id="from"></input>
                                </Form.Group>
                                <Form.Group>
                                    <label htmlFor="to">{getLang(localStorage.getItem('language') || 'English', 'To')}</label>
                                    <input required type="date" className="form-control" name="to" id="to"></input>
                                </Form.Group>
                                {/* <button onClick={event => { event.preventDefault(); this.sendData(); }} className="btn btn-primary mr-2">View</button> */}
                                <input type="submit" value="Submit" />
                            </form>
                        </div>
                    </div>
                </div>
            </div >
        )
    }
}

export default Reports
