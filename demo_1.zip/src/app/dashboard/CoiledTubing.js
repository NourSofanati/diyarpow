import React, { Component } from 'react'

import { Form } from 'react-bootstrap';
import getLang from './Translations'
export class CoiledTubing extends Component {
    componentDidMount() {
        fetch("https://diyarpower.com/scripts/Fields/read.php")
            .then(response => response.json())
            .then(result => {


                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ data: x });

                console.log(this.state);
            })
            .catch(error => console.log('error', error));
    }

    componentWillMount() {
        this.setState({ language: localStorage.getItem("language") });
        fetch("https://diyarpower.com/scripts/Fields/read.php")
            .then(response => response.json())
            .then(result => {
                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ data: x });

                console.log(this.state);
            })
            .catch(error => console.log('error', error));

        fetch("https://diyarpower.com/scripts/Wells/read.php")
            .then(response => response.json())
            .then(result => {

                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ wells: x });

                console.log(this.state);
            })
            .catch(error => console.log('error', error));
    }

    state = {
        data: [],
        wells: [],
        date: new Date(),
        language: localStorage.getItem('language') || "English"
    };

    render() {
        return (
            <div>
                <form className="forms-sample">
                    <Form.Group>
                        <label htmlFor="date">{getLang(this.state.language, "Date")}</label><br></br>
                        <input className="form-control w-100" id="date" type="date" size="lg" selected={this.state.date} />
                    </Form.Group>
                    <Form.Group>
                        <label htmlFor="fieldName">{getLang(this.state.language, "Field Name")}</label>
                        <Form.Control as="select" id="fieldName" placeholder="Field Name" size="lg" >
                            {
                                this.state.data.map(el => <option val={el.field_name} size="lg" >{el.field_name}</option>)
                            }
                        </Form.Control>
                    </Form.Group>
                    <Form.Group>
                        <label htmlFor="wellNO">{getLang(this.state.language, "Well NO")}</label>
                        <Form.Control as="select" id="wellNO" placeholder="Field Name" size="lg" >
                            {
                                this.state.wells.map(el => <option val={el.wellNO} size="lg" >{el.wellNO}</option>)
                            }
                        </Form.Control>
                    </Form.Group>
                    <Form.Group>
                        <label htmlFor="netOil">{getLang(this.state.language, "Material")}</label>
                        <Form.Control type="text" className="form-control" id="netOil" placeholder="Material injected in coiled tubes" />
                    </Form.Group>
                    <Form.Group>
                        <label htmlFor="workingTime">{getLang(this.state.language, "Method")}</label>
                        <Form.Control type="text" step="0.01" className="form-control" id="workingTime" placeholder="Method used to inject material" />
                    </Form.Group>

                    <button className="btn btn-primary mr-2">{getLang(this.state.language, "Submit")}</button>
                    <button className="btn btn-light">{getLang(this.state.language, "Cancel")}</button>
                </form>
            </div>
        )
    }
}

export default CoiledTubing
