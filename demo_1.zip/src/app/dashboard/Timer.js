import React, { Component } from 'react'

export class TimerPage extends Component {
    state = {
        data: []
    };
    componentWillMount() {
        fetch("https://diyarpower.com/scripts/Tanks/read.php")
            .then(blob => blob.json())
            .then(data => {
                this.setState({
                    data: data,
                })
            })
    }
    render() {
        return (
            <div>
                <div className="page-header">
                    <h3 className="page-title"> Timer and tanks </h3>
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><a href="!#" onClick={event => event.preventDefault()}>Dashboard</a></li>
                            <li className="breadcrumb-item active" aria-current="page">Timer and tanks</li>
                        </ol>
                    </nav>
                </div>
                <div className="col-md-12 grid-margin stretch-card">
                    <div className="card p-3">
                        <table className="table table-hover cursor-pointer" >
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Diameter</th>
                                    <th>Length</th>
                                    <th>Wells</th>
                                    <th>Field</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.data.map(
                                        tank => {
                                            return <tr onClick={(e) => { window.location.href = `https://diyarpower.com/scripts/Tanks/test.php?id=${tank.id}` }}>
                                                <td>{tank.id}</td>
                                                <td>{tank.diameter}</td>
                                                <td>{tank.length}</td>
                                                <td>{tank.wells.map(well=>{return<p className="badge badge-primary mr-1">{well}</p>})}</td>
                                                <td>{tank.field_name}</td>
                                            </tr>
                                        }
                                    )
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
            </div >
        )
    }
}

export default TimerPage
