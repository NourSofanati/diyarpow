import React, { Component } from 'react'
import { Form } from 'react-bootstrap';
import { withRouter } from 'react-router-dom';
import getLang from './Translations'
export class WaterCutReport extends Component {
    state = {
        data: []
    };
    componentDidMount() {
        fetch("https://diyarpower.com/scripts/Fields/read.php")
            .then(response => response.json())
            .then(result => {
                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ data: x });
                console.log(this.state);
            })
            .catch(error => console.log('error', error));
    }

    componentWillMount() {
        fetch("https://diyarpower.com/scripts/Fields/read.php")
            .then(response => response.json())
            .then(result => {
                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ data: x });

                console.log(this.state);
            })
            .catch(error => console.log('error', error));
    }

    resetForm() {

        document.querySelector('#wellNO').value = '';
        document.querySelector('#netOil').value = '';
        document.querySelector('#workingTime').value = '';
    }

    sendData() {

        fetch("https://diyarpower.com/scripts/WaterCut/read.php")
            .then(response => response.json())
            .then(waterResult => {
                console.log(waterResult);
                let table = document.querySelector('#insertDataHere');
                table.innerHTML = '';
                console.table(waterResult.data);
                waterResult.data.sort((a, b) => {
                    let aDate = new Date(a.date);
                    let bDate = new Date(b.date);
                    return aDate - bDate;
                })
                waterResult.data.forEach(el => {
                    table.innerHTML += `<tr>
                                <td>${el.field_name}</td>
                                <td>${el.wellNO}</td>
                                <td>${el.date}</td>
                                <td>${el.water_cut}</td>
                                <td>${el.notes}</td>
                            </tr>`;
                });
            })
            .catch(error => console.log('error', error));
    }

    render() {
        return (
            <div>
                <div className="page-header">
                    <h3 className="page-title"> {getLang(localStorage.getItem('language') || 'English', 'View reports')} </h3>
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><a href="!#" onClick={event => event.preventDefault()}>{getLang(localStorage.getItem('language') || 'English', 'Dashboard')}</a></li>
                            <li className="breadcrumb-item active" aria-current="page">{getLang(localStorage.getItem('language') || 'English', 'Water cut')}</li>
                        </ol>
                    </nav>
                </div>
                <div className="col-md-12 grid-margin stretch-card">
                    <div className="card">
                        <div className="card-header">
                            <h3>{getLang(localStorage.getItem('language') || 'English', 'View water cut report for well')}</h3>
                        </div>
                        <div className="card-body">

                            <form className="forms-sample">
                                <Form.Group>
                                    <label htmlFor="wellNO">{getLang(localStorage.getItem('language') || 'English', 'Well NO')}</label>
                                    <Form.Control type="text" id="wellNO" placeholder="Well Number" size="lg" />
                                </Form.Group>
                                <button onClick={event => { event.preventDefault(); this.sendData(); }} className="btn btn-primary mr-2">{getLang(localStorage.getItem('language')||'English','View')}</button>
                            </form>
                        </div>

                        <table className="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>{getLang(localStorage.getItem('language')||'English','Field Name')}</th>
                                    <th>{getLang(localStorage.getItem('language')||'English','Well NO')}</th>
                                    <th>{getLang(localStorage.getItem('language')||'English','Sample date')}</th>
                                    <th>{getLang(localStorage.getItem('language')||'English','Water content')}</th>
                                    <th>{getLang(localStorage.getItem('language')||'English','Notes')}</th>
                                </tr>
                            </thead>
                            <tbody id="insertDataHere">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div >
        )
    }
}

export default withRouter(WaterCutReport)
