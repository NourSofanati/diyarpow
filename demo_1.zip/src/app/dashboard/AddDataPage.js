import React, { Component } from 'react'
import { Form } from 'react-bootstrap';
import getLang from './Translations'
import {
  GridComponent,
  ColumnDirective,
  ColumnsDirective,
  Page,
  Filter,
  Inject,
  Toolbar,
  Edit

} from '@syncfusion/ej2-react-grids';
export class AddDataPage extends Component {
  state = {
    data: [],
    wells: [],
    date: new Date(),
    language: localStorage.getItem('language') || "English",
    oilp: []
  };
  componentDidMount() {
    fetch("https://diyarpower.com/scripts/Fields/read.php")
      .then(response => response.json())
      .then(result => {


        let x = [];
        result.data.forEach(element => {
          x.push(element);
        });
        this.setState({ data: x });

        console.log(this.state);
      })
      .catch(error => console.log('error', error));
    this.setState({ language: localStorage.getItem("language") });
    fetch("https://diyarpower.com/scripts/Fields/read.php")
      .then(response => response.json())
      .then(result => {
        let x = [];
        result.data.forEach(element => {
          x.push(element);
        });
        this.setState({ data: x });

        console.log(this.state);
      })
      .catch(error => console.log('error', error));

    fetch("https://diyarpower.com/scripts/Wells/read.php")
      .then(response => response.json())
      .then(result => {

        let x = [];
        result.data.forEach(element => {
          x.push(element);
        });
        this.setState({ wells: x });

        console.log(this.state);
      })
      .catch(error => console.log('error', error));

    fetch("https://diyarpower.com/scripts/OilReport/readById.php")
      .then(response => response.json())
      .then(result => {
        this.setState({ oilp: result });
      })
  }


  resetForm() {
    document.querySelector('#netOil').value = '';
    document.querySelector('#workingTime').value = '';
  }

  sendData() {
    let date = document.querySelector('#date').value.split('/');
    let field_name = document.querySelector('#fieldName').value;
    let wellNO = document.querySelector('#wellNO').value;
    let fpd = document.querySelector('#netOil').value;
    let working_time = document.querySelector('#workingTime').value;
    var raw = JSON.stringify({
      "username": JSON.parse(localStorage.getItem('userData')).username,
      "sampling_date": `${date[2]}-${date[0]}-${date[1]}`,
      "field_name": field_name,
      "wellNO": wellNO,
      "fpd": fpd,
      "working_time": working_time
    });
    console.log(raw);

    var requestOptions = {
      method: 'POST',
      body: raw,
      redirect: 'manual'
    };

    fetch("https://diyarpower.com/scripts/OilReport/create.php", requestOptions)
      .then(response => response.json())
      .then(result => {
        fetch("https://diyarpower.com/scripts/OilReport/readById.php")
          .then(response => response.json())
          .then(x => {
            this.setState({ oilp: x });
          });
        console.log(result); alert("Created new record successfuly."); this.resetForm();
      })
      .catch(error => {
        console.log('error', error); alert("تم اضافة البيانات"); fetch("https://diyarpower.com/scripts/OilReport/readById.php")
          .then(response => response.json())
          .then(result => {
            this.setState({ oilp: result });
          })
      });

  }

  render() {
    return (
      <div>
        <div className="page-header">
          <h3 className="page-title"> Add Data </h3>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item"><a href="!#" onClick={event => event.preventDefault()}>Dashboard</a></li>
              <li className="breadcrumb-item active" aria-current="page">Add Data</li>
            </ol>
          </nav>
        </div>
        <div className="col-md-12 grid-margin stretch-card">
          <div className="card">
            <div className="card-body">
              <h4 className="card-title">{getLang(this.state.language, "New data entry")}</h4>

              <form className="forms-sample">
                <Form.Group>
                  <label htmlFor="date">{getLang(this.state.language, "Date")}</label><br></br>
                  <input className="form-control w-100" id="date" type="date" size="lg" selected={this.state.date} />
                </Form.Group>
                <Form.Group>
                  <label htmlFor="fieldName">{getLang(this.state.language, "Field Name")}</label>
                  <Form.Control as="select" id="fieldName" placeholder="Field Name" size="lg" >
                    {
                      this.state.data.map(el => <option val={el.field_name} key={el.field_name} size="lg" >{el.field_name}</option>)
                    }
                  </Form.Control>
                </Form.Group>
                <Form.Group>
                  <label htmlFor="wellNO">{getLang(this.state.language, "Well NO")}</label>
                  <Form.Control as="select" id="wellNO" placeholder="Field Name" size="lg" >
                    {
                      this.state.wells.map(el => <option val={el.wellNO} key={el.wellNO} size="lg" >{el.wellNO}</option>)
                    }
                  </Form.Control>
                </Form.Group>
                <Form.Group>
                  <label htmlFor="netOil">{getLang(this.state.language, "FPD")} (M<sup>3</sup>)</label>
                  <Form.Control type="number" className="form-control" id="netOil" placeholder="FPD volume (meter squared)" />
                </Form.Group>
                <Form.Group>
                  <label htmlFor="workingTime">{getLang(this.state.language, "Working Time")}</label>
                  <Form.Control type="number" step="0.01" className="form-control" id="workingTime" placeholder="Hours Operated" />
                </Form.Group>

                <button onClick={event => { event.preventDefault(); this.sendData(); }} className="btn btn-primary mr-2">{getLang(this.state.language, "Submit")}</button>
                <button className="btn btn-light">{getLang(this.state.language, "Cancel")}</button>
              </form>
            </div>
          </div>
        </div>
        <div className="col-md-12 grid-margin stretch-card">
          <div className="card">
            <div className="card-body">

              <GridComponent
                dataSource={this.state.oilp}
                allowFiltering={true}
                allowPaging={true}
                pageSettings={{ pageSize: 20 }}
                toolbar={['Delete', 'Edit', 'Update', 'Cancel']}
                editSettings={{
                  showDeleteConfirmDialog: true,
                  allowDeleting: true,
                  mode: 'Dialog',
                  showConfirmDialog: true,
                  allowEditing: true,
                }}
                actionBegin={(e) => {
                  console.log(e);
                  switch (e.requestType) {
                    case "delete":
                      fetch("https://diyarpower.com/scripts/OilReport/delete.php?id=" + e.data[0].id, {
                        method: 'DELETE'
                      })
                      break;
                    case 'save':
                      fetch("https://diyarpower.com/scripts/OilReport/edit.php", {
                        method: 'PUT',
                        headers: {
                          'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(e.data),
                      }).then(raw => raw.json())
                        .then(data => { alert(data.message); this.setState({ oilp: data.data }) });
                      break;
                    default:
                      break;
                  }
                }}
              >
                <ColumnsDirective>
                  <ColumnDirective field='id' headerText='ID' textAlign='Right' width='100' isPrimaryKey={true} />
                  <ColumnDirective field='wellNO' headerText='WellNO' width='150' />
                  <ColumnDirective field='sampling_date' headerText='Sampling Date' format={{ type: 'date' }} />
                  <ColumnDirective field='fpd' headerText='FPD' />
                  <ColumnDirective field='working_time' headerText='Working Time' />

                </ColumnsDirective>
                <Inject services={[Page, Filter, Edit, Toolbar]} />
              </GridComponent>
            </div>
          </div>
        </div>
      </div >
    )
  }
}

export default AddDataPage
