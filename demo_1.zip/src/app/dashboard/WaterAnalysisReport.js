import React, { Component } from 'react'
import { Form } from 'react-bootstrap';
import DatePicker from "react-datepicker";
import getLang from './Translations'
export class WaterAnalysisPage extends Component {
    state = {
        data: []
    };
    componentDidMount() {
        fetch("https://diyarpower.com/scripts/Fields/read.php")
            .then(response => response.json())
            .then(result => {


                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ data: x });

                console.log(this.state);
            })
            .catch(error => console.log('error', error));
    }

    componentWillMount() {
        fetch("https://diyarpower.com/scripts/Fields/read.php")
            .then(response => response.json())
            .then(result => {
                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ data: x });

                console.log(this.state);
            })
            .catch(error => console.log('error', error));
    }

    resetForm() {

        document.querySelector('#wellNO').value = '';
        document.querySelector('#netOil').value = '';
        document.querySelector('#workingTime').value = '';
    }

    sendData() {
        let date = document.querySelector('#date').value.split('/');
        let field_name = document.querySelector('#fieldName').value;
        let wellNO = document.querySelector('#wellNO').value;
        let fpd = document.querySelector('#netOil').value;
        let working_time = document.querySelector('#workingTime').value;
        var raw = JSON.stringify({
            "username": JSON.parse(localStorage.getItem('userData')).username,
            "sampling_date": `${date[2]}-${date[0]}-${date[1]}`,
            "field_name": field_name,
            "wellNO": wellNO,
            "fpd": fpd,
            "working_time": working_time
        });
        console.log(raw);

        var requestOptions = {
            method: 'POST',
            body: raw,
            redirect: 'manual'
        };

        fetch("https://diyarpower.com/scripts/OilReport/create.php", requestOptions)
            .then(response => response.json())
            .then(result => { console.log(result); alert("Created new record successfuly."); this.resetForm(); })
            .catch(error => { console.log('error', error); alert("An error occured while trying to submit data:\n" + error); });
    }

    render() {
        return (
            <div>
                <div className="page-header">
                    <h3 className="page-title"> {getLang(localStorage.getItem('language') || 'English', 'Add Water analyisis report Data')} </h3>
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><a href="!#" onClick={event => event.preventDefault()}>{getLang(localStorage.getItem('language') || 'English', 'Dashboard')}</a></li>
                            <li className="breadcrumb-item active" aria-current="page">{getLang(localStorage.getItem('language') || 'English', 'Add Data')}</li>
                        </ol>
                    </nav>
                </div>
                <div className="col-md-12 grid-margin stretch-card">
                    <div className="card">
                        <div className="card-body">


                            <form className="forms-sample">
                                <Form.Group>
                                    <label htmlFor="date">{getLang(localStorage.getItem('language') || 'English', 'Date')}</label><br></br>
                                    <DatePicker className="form-control w-100" id="date" size="lg" selected={new Date()} />
                                </Form.Group>
                                <Form.Group>
                                    <label htmlFor="fieldName">{getLang(localStorage.getItem('language') || 'English', 'Field Name')}</label>
                                    <Form.Control as="select" id="fieldName" placeholder="Field Name" size="lg" >
                                        {
                                            this.state.data.map(el => <option val={el.field_name} size="lg" >{el.field_name}</option>)
                                        }
                                    </Form.Control>
                                </Form.Group>
                                <Form.Group>
                                    <label htmlFor="wellNO">{getLang(localStorage.getItem('language') || 'English', 'Well NO')}</label>
                                    <Form.Control type="text" id="wellNO" placeholder="Well" size="lg" />
                                </Form.Group>
                                <Form.Group>
                                    <label htmlFor="netOil">{getLang(localStorage.getItem('language') || 'English', 'pH')}</label>
                                    <Form.Control type="number" className="form-control" id="netOil" placeholder="pH" />
                                </Form.Group>
                                <div className="row">
                                    <div className="col-1 text-center">
                                        <br></br>

                                        <h4>Cl<sup>-</sup></h4>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor="workingTime">{getLang(localStorage.getItem('language')||'English','Mg equ /Liter')}</label>
                                            <Form.Control type="number" step="0.01" className="form-control" id="workingTime" placeholder="Mg equ/Liter" />
                                        </Form.Group>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor="workingTime">{getLang(localStorage.getItem('language')||'English','Mg /Liter')}</label>
                                            <Form.Control type="number" step="0.01" className="form-control" id="workingTime" placeholder="Mg /Liter" />
                                        </Form.Group>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-1 text-center">
                                        <br></br>

                                        <h4>Ca<sup>++</sup></h4>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor="workingTime">{getLang(localStorage.getItem('language')||'English','Mg equ /Liter')}</label>
                                            <Form.Control type="number" step="0.01" className="form-control" id="workingTime" placeholder="Mg equ/Liter" />
                                        </Form.Group>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor="workingTime">{getLang(localStorage.getItem('language')||'English','Mg /Liter')}</label>
                                            <Form.Control type="number" step="0.01" className="form-control" id="workingTime" placeholder="Mg /Liter" />
                                        </Form.Group>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-1 text-center">
                                        <br></br>

                                        <h4>Mg<sup>++</sup></h4>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor="workingTime">{getLang(localStorage.getItem('language') || 'English', 'Mg equ /Liter')}</label>
                                            <Form.Control type="number" step="0.01" className="form-control" id="workingTime" placeholder="Mg equ/Liter" />
                                        </Form.Group>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor="workingTime">{getLang(localStorage.getItem('language') || 'English', 'Mg /Liter')}</label>
                                            <Form.Control type="number" step="0.01" className="form-control" id="workingTime" placeholder="Mg /Liter" />
                                        </Form.Group>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-1 text-center">
                                        <br></br>

                                        <h4>H<sub>2</sub>S</h4>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor="workingTime">{getLang(localStorage.getItem('language') || 'English', 'Mg equ /Liter')}</label>
                                            <Form.Control type="number" step="0.01" className="form-control" id="workingTime" placeholder="Mg equ/Liter" />
                                        </Form.Group>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor="workingTime">{getLang(localStorage.getItem('language') || 'English', 'Mg /Liter')}</label>
                                            <Form.Control type="number" step="0.01" className="form-control" id="workingTime" placeholder="Mg /Liter" />
                                        </Form.Group>
                                    </div>
                                </div>

                                <button onClick={event => { event.preventDefault(); this.sendData(); }} className="btn btn-primary mr-2">{getLang(localStorage.getItem('language') || 'English', 'Submit')}</button>
                                <button className="btn btn-light">{getLang(localStorage.getItem('language') || 'English', 'Cancel')}</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div >
        )
    }
}

export default WaterAnalysisPage
