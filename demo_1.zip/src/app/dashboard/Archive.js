import React, { Component } from 'react'

export class Archive extends Component {
    render() {
        return (
            <div className="">
                <iframe src="https://diyarpower.com/Archives/archives.php" frameborder="0" width="100%" height="760px"  title="Archives"></iframe>
            </div>
        )
    }
}

export default Archive
