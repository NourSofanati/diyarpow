import React, { Component } from 'react'
import ModalImage from "react-modal-image";
import { Link } from 'react-router-dom';

import Highcharts from "highcharts/highstock";
import HighchartsReact from 'highcharts-react-official'
import highcharts3d from 'highcharts/highcharts-3d'

import 'highcharts/modules/full-screen'
import HC_export from 'highcharts/modules/export-data'
import HC_exporting from 'highcharts/modules/exporting'
import 'highcharts/modules/accessibility'
import HC_timeline from 'highcharts/modules/data'
import getLang from './Translations'
highcharts3d(Highcharts);
HC_exporting(Highcharts);
HC_export(Highcharts);
HC_timeline(Highcharts);

export class Wells extends Component {
    state = {
        wells: []
    };
    componentDidMount() {
    }

    generateChart(el, awpa) {
        let wc = el.water_content_before;
        let bo = el.base_oil;
        let tlb = el.total_liquid_before;
        let newData = el.newData;
        if (el.awpa === 1) {
            return <div className="chart-container">

                <HighchartsReact
                    highcharts={Highcharts}
                    options={{
                        chart: {
                            type: 'column',
                            options3d: {
                                enabled: true,
                                alpha: 0,
                                beta: 0,
                                depth: 20,
                                viewDistance: 20
                            },
                        },
                        exporting: {
                            enabled: true
                        },
                        fullscreen: {
                            enabled: true
                        },
                        accessibility: {
                            enabled: true
                        },
                        legend: { enabled: true },
                        title: {
                            text: el.wellNO + getLang(localStorage.getItem('language') || 'English', ' well investigation')
                        },
                        xAxis: {
                            categories: [getLang(localStorage.getItem('language') || 'English', "Before"), getLang(localStorage.getItem('language') || 'English', "After")]
                        },
                        series: [{
                            data: [{ y: parseFloat(tlb), color: '#e8ded2', name: 'Total Liquid Before' }, { y: parseFloat(newData.avg_fpd * 6.28981), color: '#460ead', name: 'Total Liquid After' }],

                            name: getLang(localStorage.getItem('language') || 'English', 'Total Liquid')
                        }, {
                            data: [{ color: '#5eaaa8', y: parseFloat(wc), name: 'Water Content Before' }, { color: '#128bfc', y: parseFloat(newData.avg_wc), name: 'Water Content After' },],

                            name: getLang(localStorage.getItem('language') || 'English', 'Water Content')
                        }, {
                            data: [{ color: '#056676', y: (parseFloat(bo)), name: 'Base Oil Before' }, {
                                color: '#f58b27',
                                y: (parseFloat(Math.abs(((newData.avg_wc / 100) * newData.avg_fpd) - newData.avg_fpd) * 6.28981)), name: 'Base Oil After'
                            }],

                            name: getLang(localStorage.getItem('language') || 'English', 'Base oil')
                        }],
                        credits: {
                            enabled: false
                        },
                    }}
                    containerProps={{ style: { height: "400px" } }}
                />

            </div>
        }; return <div className="chart-container">
            <HighchartsReact
                highcharts={Highcharts}
                options={{
                    chart: {
                        type: 'column',
                        options3d: {
                            enabled: true,
                            alpha: 0,
                            beta: 0,
                            depth: 20,
                            viewDistance: 20
                        },
                    },
                    exporting: {
                        enabled: true
                    },
                    fullscreen: {
                        enabled: true
                    },
                    accessibility: {
                        enabled: true
                    },
                    title: {
                        text: el.wellNO + getLang(localStorage.getItem('language') || 'English', ' well investigation')
                    },
                    xAxis: {
                        categories: [getLang(localStorage.getItem('language') || 'English', "Data")]
                    },
                    series: [{
                        data: [[getLang(localStorage.getItem('language') || 'English', "Total Liquid Before /bbls"), parseFloat(tlb)]],
                        color: '#460ead',
                        name: getLang(localStorage.getItem('language') || 'English', 'Total Liquid')
                    }, {
                        data: [[getLang(localStorage.getItem('language') || 'English', "Water Content Before /bbls"), (parseFloat(tlb) * (parseFloat(wc) / 100))]],
                        color: '#128bfc',
                        name: getLang(localStorage.getItem('language') || 'English', 'Water Content')
                    }, {
                        data: [[getLang(localStorage.getItem('language') || 'English', "Base oil Before /bbls"), (parseFloat(bo))]],
                        color: '#f58b27',
                        name: getLang(localStorage.getItem('language') || 'English', 'Base oil')
                    }],
                    credits: {
                        enabled: false
                    },
                }}
                containerProps={{ style: { height: "400px" } }}
            />

        </div>
    }

    componentWillMount() {
        fetch('https://diyarpower.com/scripts/Wells/read.php').then(blob => blob.json()).then(data => {
            this.setState({ wells: data.data });
        })
    }


    render() {
        return (
            <div>
                <div className="page-header">
                    <h3 className="page-title"> {getLang(localStorage.getItem('language') || 'English', 'View wells')} </h3>
                    <Link className="btn btn-primary">{getLang(localStorage.getItem('language') || 'English', 'Add New Well')}</Link>
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><a href="!#" onClick={event => event.preventDefault()}>{getLang(localStorage.getItem('language') || 'English', 'Dashboard')}</a></li>
                            <li className="breadcrumb-item active" aria-current="page">{getLang(localStorage.getItem('language') || 'English', 'Well data')}</li>
                        </ol>
                    </nav>
                </div>
                <div className="row" id="tthere">
                    {
                        this.state.wells.map((el) => {

                            let picURL = el.wellNO.split('-')[1];
                            return <div className="col-lg-4 col-md-6 col-sm-12 mb-2">
                                <div className="card">
                                    <div className="card-header">
                                        <h4>{el.wellNO} {el.awpa === 1 ? <div className="badge badge-success">AWPA</div> : null}   </h4>

                                    </div>
                                    <div className="card-body">

                                        {this.generateChart(el, el.awpa)}

                                        <ModalImage
                                            small={require(`../../assets/images/WD${picURL}.jpg`)}
                                            large={require(`../../assets/images/WD${picURL}.jpg`)}
                                            imageBackgroundColor="white"
                                            alt={el.wellNO}
                                        />

                                    </div>
                                </div>
                            </div>
                        }
                        )
                    }
                </div>
            </div >
        )
    }
}

export default Wells
