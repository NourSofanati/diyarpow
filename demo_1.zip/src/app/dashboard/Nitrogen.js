import React, { Component } from 'react'
import { Form } from 'react-bootstrap';
import getLang from './Translations'

export class Nitrogen extends Component {

    state = {
        data: [],
        wells: [],
        date: new Date(),
        language: localStorage.getItem('language') || "English"
    };
    componentDidMount() {
        fetch("https://diyarpower.com/scripts/Fields/read.php")
            .then(response => response.json())
            .then(result => {


                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ data: x });

                console.log(this.state);
            })
            .catch(error => console.log('error', error));
    }

    componentWillMount() {
        this.setState({ language: localStorage.getItem("language") });
        fetch("https://diyarpower.com/scripts/Fields/read.php")
            .then(response => response.json())
            .then(result => {
                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ data: x });

                console.log(this.state);
            })
            .catch(error => console.log('error', error));

        fetch("https://diyarpower.com/scripts/Wells/read.php")
            .then(response => response.json())
            .then(result => {

                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ wells: x });

                console.log(this.state);
            })
            .catch(error => console.log('error', error));
    }

    render() {
        return (
            <div>
                <form className="forms-sample">
                    <Form.Group>
                        <label htmlFor="date">{getLang(this.state.language, "Date")}</label><br></br>
                        <input className="form-control w-100" id="date" type="date" size="lg" selected={this.state.date} />
                    </Form.Group>
                    <Form.Group>
                        <label htmlFor="fieldName">{getLang(this.state.language, "Field Name")}</label>
                        <Form.Control as="select" id="fieldName" placeholder="Field Name" size="lg" >
                            {
                                this.state.data.map(el => <option val={el.field_name} size="lg" >{el.field_name}</option>)
                            }
                        </Form.Control>
                    </Form.Group>
                    <Form.Group>
                        <label htmlFor="wellNO">{getLang(this.state.language, "Well NO")}</label>
                        <Form.Control as="select" id="wellNO" placeholder="Field Name" size="lg" >
                            {
                                this.state.wells.map(el => <option val={el.wellNO} size="lg" >{el.wellNO}</option>)
                            }
                        </Form.Control>
                    </Form.Group>
                    <Form.Group>
                        <label htmlFor="netOil">Nitrogen (M<sup>3</sup>)</label>
                        <Form.Control type="number" className="form-control" id="netOil" placeholder="Nitrogen volume (meter squared)" />
                    </Form.Group>
                    <Form.Group>
                        <button className="btn btn-primary mr-2">{getLang(this.state.language, "Submit")}</button>
                        <button className="btn btn-light">{getLang(this.state.language, "Cancel")}</button>
                    </Form.Group>
                </form>
            </div>
        )
    }
}

export default Nitrogen
