let js = `[
  {
    "English": "well investigation",
    "Arabic": "التحقق من البئر",
    "Spanish": "bien investigacion"
  },
  {
    "English": "Add Data",
    "Arabic": "إضافة المعلومات",
    "Spanish": "Agregar datos"
  },
  {
    "English": "Add New Well",
    "Arabic": "إضافة بئر جديد",
    "Spanish": "Agregar nuevo pozo"
  },
  {
    "English": "Add Oil analysis Data",
    "Arabic": "إضافة معلومات تحليل النفط",
    "Spanish": "Agregar datos de análisis de aceite"
  },
  {
    "English": "Add oil analysis report",
    "Arabic": "إضافة تقرير تحليل النفط",
    "Spanish": "Agregar informe de análisis de aceite"
  },
  {
    "English": "Add Production Data",
    "Arabic": "إضافة معلومات الإنتاج",
    "Spanish": "Agregar datos de producción"
  },
  {
    "English": "Add Water analyisis report Data",
    "Arabic": "إضافة معلومات تقرير تحليل المياه",
    "Spanish": "Agregar datos de informe de análisis de agua"
  },
  {
    "English": "Add water analysis report",
    "Arabic": "إضافة تقرير تحليل المياه",
    "Spanish": "Agregar informe de análisis de agua"
  },
  {
    "English": "Add Watercut data",
    "Arabic": "أضافة معلومات  نسبة المياه",
    "Spanish": "Agregar datos de corte de agua"
  },
  {
    "English": "Additional Percentage",
    "Arabic": "نسبة إضافية",
    "Spanish": "Porcentaje adicional"
  },
  {
    "English": "Analysis reports",
    "Arabic": "تقارير التحاليل",
    "Spanish": "Informes de análisis"
  },
  {
    "English": "Arabic",
    "Arabic": "عربى",
    "Spanish": "Arábica"
  },
  {
    "English": "Average water-cut percentage",
    "Arabic": "متوسط ??نسبة قطع المياه",
    "Spanish": "Porcentaje medio de corte de agua"
  },
  {
    "English": "Base Oil",
    "Arabic": "النفط الأساس",
    "Spanish": "Aceite base"
  },
  {
    "English": "Base Oil After",
    "Arabic": "نفط الأساس بعد",
    "Spanish": "Aceite base después"
  },
  {
    "English": "Base Oil Before",
    "Arabic": "نفط الأساس قبل",
    "Spanish": "Aceite base antes"
  },
  {
    "English": "Base oil Before /bbls",
    "Arabic": "نفط الأساس قبل / برميل",
    "Spanish": "Aceite base Antes / bbls"
  },
  {
    "English": "Change Password",
    "Arabic": "تغيير كلمة السر",
    "Spanish": "Cambia la contraseña"
  },
  {
    "English": "Dashboard",
    "Arabic": "لوحة القيادة",
    "Spanish": "Tablero"
  },
  {
    "English": "English",
    "Arabic": "الإنجليزية",
    "Spanish": "Inglés"
  },
  {
    "English": "Gas",
    "Arabic": "غاز",
    "Spanish": "Gas"
  },
  {
    "English": "Generate Report",
    "Arabic": "انشاء تقرير",
    "Spanish": "Generar informe"
  },
  {
    "English": "has approved water content test",
    "Arabic": "وافق على اختبار محتوى الماء",
    "Spanish": "ha aprobado la prueba de contenido de agua"
  },
  {
    "English": "has stopped working",
    "Arabic": "توقف عن العمل",
    "Spanish": "ha dejado de trabajar"
  },
  {
    "English": "Just now",
    "Arabic": "الآن",
    "Spanish": "Justo ahora"
  },
  {
    "English": "Labratory",
    "Arabic": "مختبر",
    "Spanish": "Laboratorio"
  },
  {
    "English": "Login",
    "Arabic": "تسجيل الدخول",
    "Spanish": "Iniciar sesión"
  },
  {
    "English": "Manage Accounts",
    "Arabic": "إدارة الحسابات",
    "Spanish": "Cuentas de administración"
  },
  {
    "English": "Multiphase",
    "Arabic": "مولتي فيز",
    "Spanish": "Multifásico"
  },
  {
    "English": "new notifications",
    "Arabic": "إخطارات جديدة",
    "Spanish": "nuevas notificaciones"
  },
  {
    "English": "Oil Or Condensate",
    "Arabic": "نفط او مركز",
    "Spanish": "Aceite o condensado"
  },
  {
    "English": "Production",
    "Arabic": "إنتاج",
    "Spanish": "Producción"
  },
  {
    "English": "Pumps info",
    "Arabic": "معلومات المضخات",
    "Spanish": "Información de bombas"
  },
  {
    "English": "Register",
    "Arabic": "تسجيل",
    "Spanish": "Registrarse"
  },
  {
    "English": "Remote Connection",
    "Arabic": "الاتصال عن بعد",
    "Spanish": "Conección remota"
  },
  {
    "English": "Separator",
    "Arabic": "فاصل",
    "Spanish": "Separador"
  },
  {
    "English": "Sign Out",
    "Arabic": "تسجيل خروج",
    "Spanish": "Desconectar"
  },
  {
    "English": "Spanish",
    "Arabic": "الأسبانية",
    "Spanish": "Español"
  },
  {
    "English": "Timer",
    "Arabic": "المؤقت",
    "Spanish": "Temporizador"
  },
  {
    "English": "Today's Water Content Lab Results",
    "Arabic": "نتائج مختبر محتوى الماء اليوم",
    "Spanish": "Resultados de laboratorio de contenido de agua de hoy"
  },
  {
    "English": "Total Liquid",
    "Arabic": "إجمالي السائل",
    "Spanish": "Líquido total"
  },
  {
    "English": "Total Liquid After",
    "Arabic": "إجمالي السائل بعد",
    "Spanish": "Líquido total después"
  },
  {
    "English": "Total Liquid Before",
    "Arabic": "إجمالي السائل قبل",
    "Spanish": "Líquido total antes"
  },
  {
    "English": "Total Liquid Before /bbls",
    "Arabic": "إجمالي السائل قبل / برميل",
    "Spanish": "Líquido total antes / bbls"
  },
  {
    "English": "Total Production for January",
    "Arabic": "إجمالي الإنتاج لشهر تشرين الثاني",
    "Spanish": "Producción total de enero"
  },
  {
    "English": "User Pages",
    "Arabic": "صفحات المستخدم",
    "Spanish": "Páginas de usuario"
  },
  {
    "English": "View all",
    "Arabic": "مشاهدة الكل",
    "Spanish": "Ver todo"
  },
  {
    "English": "View reports",
    "Arabic": "عرض التقارير",
    "Spanish": "Ver los informes"
  },
  {
    "English": "View water cut report for well",
    "Arabic": "عرض تقرير نسبة المياه للبئر",
    "Spanish": "Ver informe de corte de agua para pozo"
  },
  {
    "English": "Water",
    "Arabic": "ماء",
    "Spanish": "Agua"
  },
  {
    "English": "Water Content After",
    "Arabic": "محتوى الماء بعد",
    "Spanish": "Contenido de agua después"
  },
  {
    "English": "Water Content Before",
    "Arabic": "محتوى الماء من قبل",
    "Spanish": "Contenido de agua antes"
  },
  {
    "English": "Water Content Before /bbls",
    "Arabic": "محتوى الماء قبل / برميل",
    "Spanish": "Contenido de agua antes / bbls"
  },
  {
    "English": "Water content test approved",
    "Arabic": "تمت الموافقة على اختبار محتوى الماء",
    "Spanish": "Prueba de contenido de agua aprobada"
  },
  {
    "English": "Water contents",
    "Arabic": "محتويات الماء",
    "Spanish": "Contenido de agua"
  },
  {
    "English": "Water cut",
    "Arabic": "نسبة المياه",
    "Spanish": "Corte de agua"
  },
  {
    "English": "Water cut reports",
    "Arabic": "تقارير نسبة المياه",
    "Spanish": "Informes de corte de agua"
  },
  {
    "English": "Watercut",
    "Arabic": "نسبة المياه",
    "Spanish": "Corte de agua"
  },
  {
    "English": "Well data",
    "Arabic": "معلومات البئر",
    "Spanish": "Bien datos"
  },
  {
    "English": "Wells",
    "Arabic": "آبار",
    "Spanish": "Wells"
  },
  {
    "English": "Write Analyisis Report",
    "Arabic": "كتابة تقارير التحاليل",
    "Spanish": "Escribir informe de análisis"
  },
  {
    "English": "You have",
    "Arabic": "يوجد لديك",
    "Spanish": "Tienes"
  },
  {
    "English": "Additional barrels this month",
    "Arabic": "البراميل الإضافية هذا الشهر",
    "Spanish": "Barriles adicionales este mes"
  },
  {
    "English": "after",
    "Arabic": "بعد",
    "Spanish": "después"
  },
  {
    "English": "Analysis",
    "Arabic": "التحاليل",
    "Spanish": "Análisis"
  },
  {
    "English": "API gravity",
    "Arabic": "",
    "Spanish": "Gravedad API"
  },
  {
    "English": "Asphaltines",
    "Arabic": "الأسفلتينات",
    "Spanish": "Asfaltinas"
  },
  {
    "English": "Average additional percentage",
    "Arabic": "متوسط نسبة الإضافية",
    "Spanish": "Porcentaje adicional promedio"
  },
  {
    "English": "Average water-cut",
    "Arabic": "متوسط نسبة الماء",
    "Spanish": "Corte de agua promedio"
  },
  {
    "English": "barrels",
    "Arabic": "براميل",
    "Spanish": "barriles"
  },
  {
    "English": "Base Oil production per day",
    "Arabic": "إنتاج النفط الاساس في اليوم",
    "Spanish": "Producción de aceite base por día"
  },
  {
    "English": "before",
    "Arabic": "قبل",
    "Spanish": "antes de"
  },
  {
    "English": "cancel",
    "Arabic": "إلغاء",
    "Spanish": "cancelar"
  },
  {
    "English": "charts",
    "Arabic": "الخطوط البيانية",
    "Spanish": "cartas"
  },
  {
    "English": "coiled Tubing",
    "Arabic": "الأنابيب الملفوفة",
    "Spanish": "tubería enrollada"
  },
  {
    "English": "comments",
    "Arabic": "التعليقات",
    "Spanish": "comentarios"
  },
  {
    "English": "current water content",
    "Arabic": "نسبة المياه الحالية",
    "Spanish": "contenido de agua actual"
  },
  {
    "English": "Dashboard",
    "Arabic": "لوحة القيادة",
    "Spanish": "Tablero"
  },
  {
    "English": "field Name",
    "Arabic": "اسم الحقل",
    "Spanish": "nombre del campo"
  },
  {
    "English": "FPD",
    "Arabic": "إنتاج النفط اليومي",
    "Spanish": "FPD"
  },
  {
    "English": "Fuel production Daily",
    "Arabic": "إنتاج النفط في اليوم",
    "Spanish": "Producción de combustible Diaria"
  },
  {
    "English": "Generate  report",
    "Arabic": "إنشاء تقرير",
    "Spanish": "Generar informe"
  },
  {
    "English": "increased production",
    "Arabic": "زيادة الإنتاج",
    "Spanish": "producción incrementada"
  },
  {
    "English": "Less water  Content in liquid",
    "Arabic": "نسبة ماء اقل في السائل",
    "Spanish": "Menos contenido de agua en líquido"
  },
  {
    "English": "liquid production",
    "Arabic": "إنتاج السائل",
    "Spanish": "producción líquida"
  },
  {
    "English": "Log in",
    "Arabic": "تسجيل دخول",
    "Spanish": "Iniciar sesión"
  },
  {
    "English": "Manage Accounts",
    "Arabic": "إدارة الحسابات",
    "Spanish": "Cuentas de administración"
  },
  {
    "English": "Mg equ/Liter",
    "Arabic": "مغ المكافئ للتر",
    "Spanish": "Mg equ / litro"
  },
  {
    "English": "mg/Liter",
    "Arabic": "مغ للتر",
    "Spanish": "mg / litro"
  },
  {
    "English": "New data entry",
    "Arabic": "إدخال انتاج جديد",
    "Spanish": "Nueva entrada de datos"
  },
  {
    "English": "Nitrogen",
    "Arabic": "نيتروجين",
    "Spanish": "Nitrógeno"
  },
  {
    "English": "Notes",
    "Arabic": "ملاحظات",
    "Spanish": "Notas"
  },
  {
    "English": "ph",
    "Arabic": "حموضة",
    "Spanish": "ph"
  },
  {
    "English": "pour point",
    "Arabic": "نقطة الصب",
    "Spanish": "punto de fluidez"
  },
  {
    "English": "register",
    "Arabic": "إنشاء حساب",
    "Spanish": "Registrarse"
  },
  {
    "English": "Remote connection",
    "Arabic": "الإتصال عن بعد",
    "Spanish": "Conección remota"
  },
  {
    "English": "Reports",
    "Arabic": "التقارير",
    "Spanish": "Informes"
  },
  {
    "English": "Resin",
    "Arabic": "خروج",
    "Spanish": "Resina"
  },
  {
    "English": "Sample date",
    "Arabic": "تاريخ العينة",
    "Spanish": "Fecha de muestra"
  },
  {
    "English": "sing out",
    "Arabic": "تسجيل خروج",
    "Spanish": "gritar"
  },
  {
    "English": "specific gravity",
    "Arabic": "الجاذبية",
    "Spanish": "Gravedad específica"
  },
  {
    "English": "status",
    "Arabic": "الحالة",
    "Spanish": "estado"
  },
  {
    "English": "submit",
    "Arabic": "إرسال",
    "Spanish": "enviar"
  },
  {
    "English": "this month",
    "Arabic": "هذا الشهر",
    "Spanish": "este mes"
  },
  {
    "English": "Time",
    "Arabic": "الوقت",
    "Spanish": "Hora"
  },
  {
    "English": "Total liquid production per day",
    "Arabic": "السائل الأجمالي في اليوم",
    "Spanish": "Producción líquida total por día"
  },
  {
    "English": "Total production",
    "Arabic": "الإنتاج الكلي",
    "Spanish": "Producción total"
  },
  {
    "English": "user pages",
    "Arabic": "صفحات للمستخدم",
    "Spanish": "páginas de usuario"
  },
  {
    "English": "view",
    "Arabic": "مشاهدة",
    "Spanish": "ver"
  },
  {
    "English": "view wells",
    "Arabic": "مشاهدة الآبار",
    "Spanish": "ver pozos"
  },
  {
    "English": "viscosity at",
    "Arabic": "اللزوجة  عند :",
    "Spanish": "viscosidad a"
  },
  {
    "English": "Water Content",
    "Arabic": "نسبة محتوى الماء",
    "Spanish": "Contenido de agua"
  },
  {
    "English": "water content after separation",
    "Arabic": "نسبة الماء بعد الفصل",
    "Spanish": "contenido de agua después de la separación"
  },
  {
    "English": "water cut report",
    "Arabic": "تقرير نسبة المياه",
    "Spanish": "informe de corte de agua"
  },
  {
    "English": "water production",
    "Arabic": "إنتاج الماء",
    "Spanish": "producción de agua"
  },
  {
    "English": "Well No",
    "Arabic": "رقم البئر",
    "Spanish": "Bueno no"
  },
  {
    "English": "wells",
    "Arabic": "الآبار",
    "Spanish": "pozos"
  },
  {
    "English": "Workover",
    "Arabic": "وورك اوفر",
    "Spanish": "Workhover"
  },
  {
    "English": "Working Time",
    "Arabic": "ساعات العمل",
    "Spanish": "Tiempo de trabajo"
  },
  {
    "English": "Write Analysis Report",
    "Arabic": "كتابة تقرير تحليل",
    "Spanish": "Escribir informe de análisis"
  },
  {
    "English": "Workhover",
    "Arabic": "وركوفر",
    "Spanish": "Workhover"
  }
]`
let x = JSON.parse(js);
export default function
    getLang(lang, term) {
    try {

        let translation = x.filter(el => el.English.trim().toLowerCase() === term.trim().toLowerCase())[0];
        let translatedWord = translation[lang];
        let completedTranslation = '';
        translatedWord.split(' ').forEach(word => {
            word = word.charAt(0).toUpperCase() + word.slice(1);
            completedTranslation += word + ' ';
        });
        return (completedTranslation);
    }
    catch (e) {

        return (term + "*");
    }
}
