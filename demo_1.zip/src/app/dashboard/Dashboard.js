import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Highcharts from "highcharts/highstock";
import HighchartsReact from 'highcharts-react-official'
import highcharts3d from 'highcharts/highcharts-3d'

import 'highcharts/modules/full-screen'
import HC_export from 'highcharts/modules/export-data'
import HC_exporting from 'highcharts/modules/exporting'
import 'highcharts/modules/accessibility'
import HC_timeline from 'highcharts/modules/data'
import getLang from './Translations'

highcharts3d(Highcharts);
HC_exporting(Highcharts);
HC_export(Highcharts);
HC_timeline(Highcharts);

function generateWaterContent(data) {
  let result = {
    chart: {
      renderTo: 'container',
      type: 'column',
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: true
    },
    fullscreen: {
      enabled: true
    },
    accessibility: {
      enabled: true
    },
    title: {
      text: getLang(localStorage.getItem('language') || 'English', 'Water Production')
    },
    xAxis: {
      categories: [...data.map(el => { return el.wellNO })]

    },

    series: [{
      data: [...data.map(el => { console.log(el.water_content_before); return parseFloat(el.water_content_before) })],
      color: '#0278ae',
      name: getLang(localStorage.getItem('language') || 'English', 'Water Content Before')
    }, {
      data: [...data.map(el => { console.log(el.water_content_before); return parseFloat(el.newData.avg_wc) })],
      color: '#51adcf',
      name: getLang(localStorage.getItem('language') || 'English', 'Water Content After')
    }]
  }
  return result
}
function generateLiquidProduction(data) {
  let result = {
    chart: {
      renderTo: 'container',
      type: 'column',
    },
    exporting: {
      enabled: true
    },
    fullscreen: {
      enabled: true
    },
    accessibility: {
      enabled: true
    },
    title: {
      text: getLang(localStorage.getItem('language') || 'English', 'Liquid Production')
    },
    xAxis: {
      categories: [...data.map(el => { return el.wellNO })]
    },
    series: [
      {
        // data: [[getLang(localStorage.getItem('language') || 'English', "Total Liquid Before"), 125], [getLang(localStorage.getItem('language') || 'English', "Total Liquid After"), 197.84]],
        data: [...data.map(el => {
          return { name: getLang(localStorage.getItem('language') || 'English', "Total Liquid Before"), y: parseFloat(el.total_liquid_before) };
        })],
        color: '#460ead',
        name: getLang(localStorage.getItem('language') || 'English', 'Total Liquid')
      },
      {
        data: [...data.map(el => {
          return { name: getLang(localStorage.getItem('language') || 'English', "Base Oil Before"), y: parseFloat(el.base_oil) };
        })],
        color: '#f58b27',
        name: getLang(localStorage.getItem('language') || 'English', 'Base Oil')
      }, {
        data: [...data.map(el => {
          return { name: getLang(localStorage.getItem('language') || 'English', "Total Liquid After"), y: parseFloat(el.newData.avg_fpd * 6.28981) };
        })],
        color: '#460ead',
        name: getLang(localStorage.getItem('language') || 'English', 'Total Liquid')
      },
      {
        data: [...data.map(el => {
          return {
            name: getLang(localStorage.getItem('language') || 'English', "Base Oil After"),
            y: parseFloat(
              (el.newData.avg_fpd - ((el.newData.avg_fpd * (el.newData.avg_wc / 100))))
            ) * 6.28981
          };
        })],
        color: '#f58b27',
        name: getLang(localStorage.getItem('language') || 'English', 'Base Oil')
      }],
    credits: {
      enabled: false
    },
  };
  return result;
}
export class Dashboard extends Component {
  state = {
    startDate: new Date(),
    inputValue: '',
    language: 'English',
    water_content_comparision: {},
    liquid_production: {},
    today_wc: [],
    fpd_chart: {},
    reportsNstuff: {},

  }
  keyboardInput = "";
  constructor() {
    super();
    this.statusChangedHandler = this.statusChangedHandler.bind(this);
    this.inputChangeHandler = this.inputChangeHandler.bind(this);
  }
  statusChangedHandler(event, id) {

    const todo = { ...this.state.todos[id] };
    todo.isCompleted = event.target.checked;

    const todos = [...this.state.todos];
    todos[id] = todo;

    this.setState({
      todos: todos
    })
  }

  inputChangeHandler(event) {
    this.setState({
      inputValue: event.target.value
    });
  }

  componentWillMount() {
    window.onkeydown = (e) => {
      this.keyboardInput += e.key;
      if (this.keyboardInput.indexOf('nayzac') >= 0) {
        window.location.href = "https://youtu.be/mdquYEw36TU";
      }
      if (this.keyboardInput.indexOf('IOI') >= 0) {
        window.location.href = "/bill"
      }
    }
    fetch("https://diyarpower.com/scripts/Wells/awpa.php").then(data => data.json()).then(data => {
      let totalLiquidProductionBefore = 0;
      let totalLiquidProductionAfter = 0;
      let baseOilBefore = 0;
      let baseOilAfter = 0;
      data.forEach(well => {
        baseOilBefore += well.base_oil;
        baseOilAfter += ((well.newData.avg_fpd) - (well.newData.avg_fpd * (well.newData.avg_wc / 100))) * 6.28981;
        totalLiquidProductionBefore += well.total_liquid_before;
        totalLiquidProductionAfter += well.newData.avg_fpd * 6.28981
      })
      this.setState({
        water_content_comparision: generateWaterContent(data),
        liquid_production: generateLiquidProduction(data),
        reportsNstuff: { baseOilAfter, baseOilBefore, totalLiquidProductionAfter, totalLiquidProductionBefore }
      });
      console.log(this.state.water_content_comparision)
    });
    this.setState({ language: localStorage.getItem("language") });
    const x = new Date();
    fetch(`https://diyarpower.com/scripts/WaterCut/today.php?date=${x.getFullYear()}-${x.getMonth() + 1}-${x.getDate()}`)
      .then(blob => blob.json())
      .then(data => {
        this.setState({
          today_wc: data,
        })
        console.log(data);
      });
    fetch(`https://diyarpower.com/scripts/OilReport/chart.php`)
      .then(blob => blob.json())
      .then(data => {
        let sum = [];
        data.forEach(well => {
          well.data.forEach(day => {
            //isNaN(sum[day[0]]) ? sum[day[0]] = 0 : sum[day[0]] += parseFloat(day[1]);
            if (sum.filter(item => item[0] === day[0]).length > 0) {
              //day[1] + day[1]
              //sum
              sum.find(item => item[0] === day[0])[1] += day[1];
            } else {
              sum.push([
                day[0],
                day[1]
              ])
            }
          });
        });
        sum.sort((a, b) => a[0] - b[0]);
        data.push({ "name": "sum", "data": sum });
        this.setState({
          fpd_chart: {

            rangeSelector: {
              enabled: true
            },
            scrollbar: {
              enabled: true,
              liveRedraw: true
            },
            navigator: {
              enabled: true, height: 100

            },
            exporting: {
              enabled: true
            },
            fullscreen: {
              enabled: true
            },
            accessibility: {
              enabled: true
            },
            title: {
              text: getLang(localStorage.getItem('language') || 'English', 'Fuel Production Daily')
            },

            xAxis: {
              type: 'datetime'
            },
            series: data,
            credits: {
              enabled: false
            },
          }
        })
        console.log(data);
      });
    console.log(this.state.language);
  }

  generateReportCard = () => {
    return <div className="card">
      <div className="card-body">
        <div className="clearfix">
          <div className="float-left">
            <i className="mdi mdi-chart-line icon-lg"></i>
          </div>
          <div className="float-right">
            <div className="fluid-container">
              <h3 className="text-right pt-3 m-0 text-dark">
                <Link to="/reports">{getLang(this.state.language, "Reports")}</Link>
              </h3>
            </div>
          </div>
        </div>
        <div className="card-content d-flex flex-column justify-content-between h93 pt-4">
          <div className="top-thing">
            <div className="text-muted">
              <h4>
                {getLang(this.state.language, "Reports")}
              </h4>
            </div>
            <div className="row">
              <div className="col"></div>
              <div className="col">
                <b>{getLang(this.state.language, "Before")}:</b>
              </div>
              <div className="col">
                <b>{getLang(this.state.language, "After")}:</b>
              </div>
            </div>
            {
              <div className="row">
                <div className="col">
                  <b>{getLang(this.state.language, "Total Liquid Production per day")}</b>
                </div>
                <div className="col">
                  <p className="">
                    {
                      this.state.reportsNstuff.totalLiquidProductionBefore ? this.state.reportsNstuff.totalLiquidProductionBefore.toFixed(2) : <span>...</span>
                    }
                  </p>
                </div>
                <div className="col">
                  <p className="" id="afterTotalLiquid">
                    {
                      this.state.reportsNstuff.totalLiquidProductionAfter ? this.state.reportsNstuff.totalLiquidProductionAfter.toFixed(2) : <span>...</span>
                    }

                    &nbsp;
              <span className="text-success">
                      {
                        this.state.reportsNstuff.totalLiquidProductionBefore ? ((this.state.reportsNstuff.totalLiquidProductionAfter / this.state.reportsNstuff.totalLiquidProductionBefore) * 100).toFixed(2) : <span>0%</span>
                      }% <i className="mdi-transfer-up mdi"></i>
                    </span>
                  </p>
                </div>
              </div>
            }
            <div className="row">
              <div className="col">
                <b>{getLang(this.state.language, "Base Oil Production per day")}</b>
              </div>
              <div className="col">
                <p className="">
                  {
                    this.state.reportsNstuff.baseOilBefore ? this.state.reportsNstuff.baseOilBefore.toFixed(2) : <span>...</span>
                  }
                </p>
              </div>
              <div className="col">
                <p className="" id="afterTotalLiquid">
                  {
                    this.state.reportsNstuff.baseOilAfter ? this.state.reportsNstuff.baseOilAfter.toFixed(2) : <span>...</span>
                  }

                    &nbsp;
              <span className="text-success">
                    {
                      this.state.reportsNstuff.baseOilBefore ? ((this.state.reportsNstuff.baseOilAfter / this.state.reportsNstuff.baseOilBefore) * 100).toFixed(2) : <span>0%</span>
                    }% <i className="mdi-transfer-up mdi"></i>
                  </span>
                </p>
              </div>
            </div>
          </div>
          <br />
          <div>

            <div className="chart-container" >
              <HighchartsReact
                highcharts={Highcharts}
                options={this.state.liquid_production}
                containerProps={{ style: { height: "400px" } }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>;
  }

  barChartThings = {
    chart: { type: 'column' },
    exporting: {
      enabled: true
    },
    fullscreen: {
      enabled: true
    },
    accessibility: {
      enabled: true
    },
    title: {
      text: getLang(localStorage.getItem('language') || 'English', 'Fuel Production Daily')
    },
    series: [{
      name: 'WD-25',
      data: this.data,
      tooltip: {
        valueDecimals: 2
      }
    }],
    credits: {
      enabled: false
    },
  }
  generateAnalysisCard = () => {
    return <div className="card">
      <div className="card-body">
        <div className="clearfix">
          <div className="float-left">
            <i className="mdi mdi-flask icon-lg"></i>
          </div>
          <div className="float-right">
            <div className="fluid-container">
              <h3 className="text-right pt-3 m-0 text-dark">{getLang(this.state.language, "Analysis")}</h3>
            </div>
          </div>
        </div>
        <div className="card-content">
          <br />
          <h4 className="text-muted">{getLang(localStorage.getItem('language') || 'English', 'Analysis reports')}</h4>
          <br />
          <h5 className="text-muted text-center">
            {getLang(this.state.language, "Water contents")} (barrels/Day)
            <hr />
          </h5>
          <div className="row">
            <div className="col"></div>
            <div className="col"><b>{getLang(this.state.language, "Before")}:</b></div>
            <div className="col"><b>{getLang(this.state.language, "After")}:</b></div>
          </div>
          <hr />
          <div className="row">
            <div className="col">
              <b>
                WD-25
              </b>
            </div>
            <div className="col">
              <p>159.8</p>
            </div>
            <div className="col">
              <p>101.7<span className="text-success">&nbsp;-36.35% <i className="mdi-transfer-down mdi"></i></span></p>
            </div>
          </div>
          <div className="row">
            <div className="col">
              <b>
                WD-29
              </b>
            </div>
            <div className="col">
              <p>124.2</p>
            </div>
            <div className="col">
              <p>75.89<span className="text-success">&nbsp;-38.89% <i className="mdi-transfer-down mdi"></i></span></p>
            </div>
          </div>
          <div className="row">
            <div className="col">
              <b>
                WD-43
              </b>
            </div>
            <div className="col">
              <p>205.8</p>
            </div>
            <div className="col">
              <p>50.57<span className="text-success">&nbsp;-75.24% <i className="mdi-transfer-down mdi"></i></span></p>
            </div>
          </div>
          <hr />
          <div className="row">
            <div className="col">
              <b>
                Total
              </b>
            </div>
            <div className="col">
              <p>489.8</p>
            </div>
            <div className="col">
              <p>228.1<span className="text-success">&nbsp;-53.42% <i className="mdi-transfer-down mdi"></i></span></p>
            </div>
          </div>

          <div className="chart-container">
            <HighchartsReact
              highcharts={Highcharts}
              options={this.state.water_content_comparision}
              containerProps={{ style: { height: "400px" } }}
            />
          </div>
        </div>
      </div>
    </div>;
  }
  render() {

    return (
      <div>
        <div className="row">
          <div className="col-12 grid-margin stretch-card ">
            <div className="card">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="mdi mdi-water icon-lg text-primary"></i>
                  </div>
                  <div className="float-right">
                    <div className="fluid-container">
                      <h3 className="text-right pt-3 m-0 text-dark ">{getLang(this.state.language, "Current Water Content")}</h3>
                    </div>
                  </div>
                </div>
                <div className="card-content">
                  <br />
                  <h4 className="text-muted">{getLang(this.state.language, "Today's Water Content Lab Results")}</h4>
                  <div className="table-responsive">
                    {
                      this.state.today_wc.length === 0 ? <i className="text-muted">{getLang(this.state.language, "There are no records today")}</i> : <table className="table table-hover">
                        <thead>
                          <tr>
                            <th>{getLang(this.state.language, "Well NO")}</th>
                            <th>{getLang(this.state.language, "Water Content")}</th>
                            <th>{getLang(this.state.language, "Time")}</th>
                          </tr>
                        </thead>
                        <tbody>
                          {
                            this.state.today_wc.map(record => {
                              return <tr>
                                <td>{record.wellNO}</td>
                                <td className="text-success">{record.water_cut}% <i className="mdi mdi-arrow-down"></i></td>
                                <td>{record.time}</td>
                              </tr>
                            })
                          }
                        </tbody>
                      </table>
                    }
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-6 col-sm-12 grid-margin stretch-card">
            {this.generateReportCard()}
          </div>
          <div className="col-lg-6 col-sm-12 grid-margin stretch-card">
            {this.generateAnalysisCard()}
          </div>
          <div className="col-lg-6 col-sm-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="mdi mdi-flask icon-lg"></i>
                  </div>
                  <div className="float-right">
                    <div className="fluid-container">
                      <Link to="workhover"><h3 className="text-right pt-3 m-0 text-dark">{getLang(this.state.language, "Workhover")}</h3></Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-6 col-sm-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="mdi mdi-flask icon-lg"></i>
                  </div>
                  <div className="float-right">
                    <div className="fluid-container">
                      <Link to="/multiphase"><h3 className="text-right pt-3 m-0 text-dark">{getLang(this.state.language, "Multiphase")}</h3></Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-6 col-sm-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="mdi mdi-flask icon-lg"></i>
                  </div>
                  <div className="float-right">
                    <div className="fluid-container">
                      <Link to="/nitrogen"><h3 className="text-right pt-3 m-0 text-dark">{getLang(this.state.language, "Nitrogen")}</h3></Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-6 col-sm-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="mdi mdi-flask icon-lg"></i>
                  </div>
                  <div className="float-right">
                    <div className="fluid-container">
                      <Link to="/coiled-tubing"><h3 className="text-right pt-3 m-0 text-dark">{getLang(this.state.language, "Coiled Tubing")}</h3></Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-12 col-sm-12 grid-margin stretch-card">
            <div className="card">
              <div className="card-body">
                <div className="clearfix">
                  <div className="float-left">
                    <i className="mdi mdi-flask icon-lg"></i>
                  </div>
                  <div className="float-right">
                    <div className="fluid-container">
                      <Link to="/wells"><h3 className="text-right pt-3 m-0 text-dark">AWPA</h3></Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-md-12 grid-margin">
            <div className="card">
              <div className="card-body">
                <div className="chart-container">
                  <HighchartsReact
                    highcharts={Highcharts}
                    options={this.state.fpd_chart}
                    containerProps={{ style: { height: "100%" } }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Dashboard;