import React, { Component } from 'react'
import { Form } from 'react-bootstrap';
export class Reports extends Component {
    state = {
        data: []
    };
    componentDidMount() {
        fetch("https://diyarpower.com/scripts/Fields/read.php")
            .then(response => response.json())
            .then(result => {
                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ data: x });

                console.log(this.state);
            })
            .catch(error => console.log('error', error));
    }

    componentWillMount() {
        fetch("https://diyarpower.com/scripts/Fields/read.php")
            .then(response => response.json())
            .then(result => {
                let x = [];
                result.data.forEach(element => {
                    x.push(element);
                });
                this.setState({ data: x });

                console.log(this.state);
            })
            .catch(error => console.log('error', error));
    }

    resetForm() {

        document.querySelector('#wellNO').value = '';
        document.querySelector('#netOil').value = '';
        document.querySelector('#workingTime').value = '';
    }

    sendData() {
        let wellNO = document.querySelector('#wellNO').value;
        var raw = JSON.stringify({
            "wellNO": wellNO,
        });
        console.log(raw);

        var requestOptions = {
            method: 'POST',
            body: raw,
            redirect: 'manual'
        };

        fetch("https://diyarpower.com/scripts/OilReport/generateReport.php", requestOptions)
            .then(response => response.json())
            .then(result => {

                var raw = JSON.stringify({ "wellNO": wellNO });
                var requestOptions = {
                    method: 'POST',
                    body: raw,
                    redirect: 'manual'
                };

                fetch("https://diyarpower.com/scripts/Lab/readWellResults.php", requestOptions)
                    .then(response => response.json())
                    .then(waterResult => {
                        console.log(waterResult);
                        let table = document.querySelector('#insertDataHere');
                        table.innerHTML = '';
                        console.table(waterResult.data);
                        let waterCut;
                        result.data.forEach(el => {

                            waterResult.data.forEach((elm, index) => {

                                waterCut = el.sampling_date === waterResult.data[index].date ? waterResult.data[index].water_cut : waterCut;
                            })
                            table.innerHTML += `<tr>
                                <td>${el.sampling_date}</td>
                                <td>${el.fpd}</td>
                                <td>${waterCut}</td>
                                <td>${((100 - waterCut) / 100 * el.fpd).toFixed(2)}</td>
                                <td>39.40</td>
                                <td>${(((((((100 - waterCut) / 100) * el.fpd) / 24) * el.working_time) * 6.28981) - 39.40).toFixed(2)}</td>
                                <td>${(((((((((100 - waterCut) / 100) * el.fpd) / 24) * el.working_time) * 6.28981) - 39.40) / 39.40) * 100).toFixed(1)}</td>
                                <td>${((((100 - waterCut) / 100) * el.fpd) / 24).toFixed(1)}</td>
                                <td>${el.working_time}</td>
                            </tr>`;
                        });
                        document.querySelector("#insertDownloadButton").innerHTML = `<a href="https://diyarpower.com/productionReport.html" className="btn btn-secondary">Download Report</a>`;
                    })
                    .catch(error => console.log('error', error));
            })
            .catch(error => console.log('error', error));
    }

    render() {
        return (
            <div>
                <div className="page-header">
                    <h3 className="page-title"> View reports </h3>
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><a href="!#" onClick={event => event.preventDefault()}>Dashboard</a></li>
                            <li className="breadcrumb-item active" aria-current="page">Add Data</li>
                        </ol>
                    </nav>
                </div>
                <div className="col-md-12 grid-margin stretch-card">
                    <div className="card">
                        <div className="card-header">
                            <h3>View report data for well</h3>
                        </div>
                        <div className="card-body">

                            <form className="forms-sample">
                                <Form.Group>
                                    <label htmlFor="wellNO">Well</label>
                                    <Form.Control type="text" id="wellNO" placeholder="Well Number" size="lg" />
                                </Form.Group>
                                <button onClick={event => { event.preventDefault(); this.sendData(); }} className="btn btn-primary mr-2">View</button>
                            </form>
                        </div>
                        <div id="insertDownloadButton"></div>
                        <table className="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>FPD (M<sup>3</sup>)</th>
                                    <th>Water cut</th>
                                    <th>Net oil</th>
                                    <th>Average prodct.reached oil</th>
                                    <th>Additional oil</th>
                                    <th>Additional percentage</th>
                                    <th>Production <small>p/H</small></th>
                                    <th>Working Time</th>
                                </tr>
                            </thead>
                            <tbody id="insertDataHere">
                            </tbody>
                        </table>
                    </div>
                </div>
            </div >
        )
    }
}

export default Reports
