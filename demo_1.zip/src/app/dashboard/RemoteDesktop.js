import React, { Component } from 'react'

export class RemoteConnectionPage extends Component {
  render() {
    return (
      <div>
        <ul>
          <li>
            Oil Well #1 - Online <span className="status-indicator online"></span> - <a href="http://82.137.247.59:8081">Connect</a>


          </li>
          <li>
            Oil Well #2 - Offline <span className="status-indicator "></span>
          </li>
          <li>Oil Well #3 - Offline <span className="status-indicator "></span></li>
        </ul>
      </div>
    )
  }
}

export default RemoteConnectionPage
