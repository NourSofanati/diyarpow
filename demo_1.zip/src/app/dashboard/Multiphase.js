import React, { Component } from 'react'
import { Form } from 'react-bootstrap';
import DatePicker from "react-datepicker";
import getLang from './Translations'
export class Multiphase extends Component {
    state = {
        data: [],
        wells: []
    };
    componentWillMount() {

    }

    render() {
        return (
            <div className="col-md-12 grid-margin stretch-card">
                <div className="card">
                    <div className="card-body">
                        <h4 className="card-title">{getLang(localStorage.getItem('language') || 'English', 'New data entry')}</h4>

                        <form className="forms-sample">
                            <div className="row">
                                <div className="col-6">
                                    <Form.Group>
                                        <label htmlFor="date">{getLang(localStorage.getItem('language') || 'English', 'Date')}</label><br />
                                        <DatePicker className="form-control w-100" id="date" size="lg" selected={new Date()} />
                                    </Form.Group>
                                </div>
                                <div className="col-6">
                                    <Form.Group>
                                        <label htmlFor="date">{getLang(localStorage.getItem('language') || 'English', 'Time')}</label><br></br>
                                        <input type="time" className="form-control w-25" name="time" id="time" />
                                    </Form.Group>
                                </div>
                            </div><hr />
                            <div>
                                <div className="row"><div className="col"><h4>Well Head</h4></div></div>
                                <div className="row">
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor=""><big>Choke </big>&nbsp;<small>/64"</small></label>
                                            <input type="text" className="w-100 form-control" />
                                        </Form.Group>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor=""><big>WHT</big>&nbsp;<small>degF</small></label>
                                            <input type="text" className="w-100 form-control" />
                                        </Form.Group>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor=""><big>WHP</big>&nbsp;<small>psig</small></label>
                                            <input type="text" className="w-100 form-control" />
                                        </Form.Group>
                                    </div>
                                </div>
                            </div>
                            <hr /><div>
                                <div className="row"><div className="col"><h4>{getLang(localStorage.getItem('language') || 'English', 'Separator')}</h4></div></div>
                                <div className="row">
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor=""><big>L Temp. </big>&nbsp;<small>degF</small></label>
                                            <input type="text" className="w-100 form-control" />
                                        </Form.Group>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor=""><big>Press.</big>&nbsp;<small>psia</small></label>
                                            <input type="text" className="w-100 form-control" />
                                        </Form.Group>
                                    </div>
                                </div>
                            </div><hr />
                            <div>
                                <div className="row"><div className="col"><h4>{getLang(localStorage.getItem('language') || 'English', 'Oil Or Condensate')}</h4></div></div>
                                <div className="row">
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor=""><big>Rate</big>&nbsp;<small>BOPD</small></label>
                                            <input type="text" className="w-100 form-control" />
                                        </Form.Group>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor=""><big>Gravity</big>&nbsp;<small>g/cc</small></label>
                                            <input type="text" className="w-100 form-control" />
                                        </Form.Group>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor=""><big>BSW</big>&nbsp;<small>%</small></label>
                                            <input type="text" className="w-100 form-control" />
                                        </Form.Group>
                                    </div>
                                </div>
                            </div><hr />
                            <div>
                                <div className="row"><div className="col"><h4>{getLang(localStorage.getItem('language') || 'English', 'Gas')}</h4></div></div>
                                <div className="row">
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor=""><big>Rate</big>&nbsp;<small>IMMSCF</small></label>
                                            <input type="text" className="w-100 form-control" />
                                        </Form.Group>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor=""><big>Gravity</big>&nbsp;<small>Air=1</small></label>
                                            <input type="text" className="w-100 form-control" />
                                        </Form.Group>
                                    </div>
                                </div>
                            </div>
                            <hr />
                            <div>
                                <div className="row"><div className="col"><h4>{getLang(localStorage.getItem('language') || 'English', 'Water')}</h4></div></div>
                                <div className="row">
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor=""><big>Rate</big>&nbsp;<small>BWPD</small></label>
                                            <input type="text" className="w-100 form-control" />
                                        </Form.Group>
                                    </div>
                                    <div className="col-4">
                                        <Form.Group>
                                            <label htmlFor=""><big>WLR</big>&nbsp;<small>%</small></label>
                                            <input type="text" className="w-100 form-control" />
                                        </Form.Group>
                                    </div>
                                </div>
                            </div>
                            <button onClick={event => { event.preventDefault(); this.sendData(); }} className="btn btn-primary mr-2">{getLang(localStorage.getItem('language') || 'English', 'Submit')}</button>
                            <button className="btn btn-light">{getLang(localStorage.getItem('language') || 'English', 'Cancel')}</button>
                        </form>
                    </div>
                </div>
            </div>
        )
    }
}

export default Multiphase
